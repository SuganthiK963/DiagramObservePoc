using Microsoft.AspNetCore.Components;
using Syncfusion.Blazor.Diagram.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Syncfusion.Blazor.Diagram
{
    public partial class SfDiagramComponent
    {
        internal static bool isProtectedOnChange = true;
        internal bool groupAction = false;
        internal bool isScriptRendered = false;
        internal static bool isJScalling = false;
        internal const string CONTENT = "_content";
        internal const string PATTERN = "_pattern";
        internal const string GRIDLINE = "gridline";
        internal string DiagramCursor = "default";
        internal DiagramLayerContent DiagramContent;
        internal bool IsDiagramRerendered { get; set; } = false;
        private string width { get; set; } = "100%";
        private string height { get; set; } = "100%";

        internal ObservableCollection<Node> nodes { get; set; } = new ObservableCollection<Node>() { };
        //internal ObservableCollection<Connector> connectors { get; set; } = new ObservableCollection<Connector>() { };
        internal bool IsBeginUpdate;
        internal bool FirstRender;
        internal DiagramAction DiagramAction { get; set; }
        internal RealAction RealAction { get; set; }

        internal string DIAGRAMADORNERLAYER;
        internal string DIAGRAMADORNERSVG;
        internal string DIAGRAMADORNER;
        internal string DIAGRAMCONTENT;

        internal string ID = "diagram";
        [JsonPropertyName("width")]
        [Parameter]
        public string Width
        {
            get { return width; }
            set
            {
                if (width != value)
                {
                    width = this.GetSizeValue(value);
                }
            }
        }
        
        /// <summary>
        /// Sets Child content for the diagram component
        /// </summary>
        [Parameter]
        [JsonIgnore]
        public RenderFragment ChildContent { get; set; }
        
        [Parameter]
        [JsonPropertyName("height")]
        public string Height
        {
            get { return height; }
            set
            {
                if (height != value)
                {
                    height = this.GetSizeValue(value);
                }
            }
        }
        
        [Parameter]
        [JsonPropertyName("nodes")]
        public ObservableCollection<Node> Nodes
        {
            get
            {
                return nodes;
            }
            set
            {
                nodes = value;
            }
        }

        //[Parameter]
        //[JsonPropertyName("connectors")]
        //public ObservableCollection<Connector> Connectors
        //{
        //    get { return connectors; }
        //    set
        //    {
        //        connectors = value;
        //    }
        //}
        
        //protected override async Task OnInitializedAsync()
        //{
        //    await base.OnInitializedAsync();
        //    DIAGRAMADORNERLAYER = ID + "_diagramAdornerLayer";
        //    DIAGRAMADORNERSVG = ID + "_diagramAdorner_svg";
        //    DIAGRAMADORNER = ID + "_diagramAdorner";
        //    DIAGRAMCONTENT = ID + CONTENT;
            
        //}
        private string GetSizeValue(string real)
        {
            string value;
            if (real.IndexOf("px") > 0 || real.IndexOf('%') > 0)
            {
                value = real;
            }
            else
            {
                value = real + "px";
            }
            return value;
        }
    }
}