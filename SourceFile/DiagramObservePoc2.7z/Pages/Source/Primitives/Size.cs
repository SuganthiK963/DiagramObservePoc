﻿using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the class that is used to describe the Size of an object.
    /// </summary>
    public class Size
    {
        /// <summary>
        /// Gets or sets the width of an object.
        /// </summary>
        [JsonPropertyName("width")]
        public double? Width { get; set; }
        /// <summary>
        /// Gets or sets the height of an object.
        /// </summary>
        [JsonPropertyName("height")]
        public double? Height { get; set; }
        internal Size Clone()
        {
            return new Size() { Width = this.Width, Height = this.Height };
        }
    }
}
