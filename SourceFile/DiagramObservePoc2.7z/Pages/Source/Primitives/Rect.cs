using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Describes the width, height, and location of a rectangle.
    /// </summary>
    public class Rect
    {
        /// <summary>
        /// Gets or sets the x-axis value of the left side of the rectangle.
        /// </summary>
        [JsonPropertyName("x")]
        public double X { get; set; } = double.MaxValue;
        /// <summary>
        /// Gets or sets the y-axis value of the top side of the rectangle.
        /// </summary>
        [JsonPropertyName("y")]
        public double Y { get; set; } = double.MaxValue;
        /// <summary>
        /// Gets or sets the width of the rectangle.
        /// </summary>
        [JsonPropertyName("width")]
        public double Width { get; set; } = 0;
        /// <summary>
        /// Gets or sets the height of the rectangle.
        /// </summary>
        [JsonPropertyName("height")]
        public double Height { get; set; } = 0;
        /// <summary>
        /// Initializes a new instance of the <see cref="Rect"/> class.
        /// </summary>
        public Rect() : base()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="Rect"/> class.
        /// </summary>
        /// <param name="src">Rect.</param>
        public Rect(Rect src)
        {
            X = src.X;
            Y = src.Y;
            Width = src.Width;
            Height = src.Height;

        }
        /// <summary>
        /// Initializes a new instance of the Rect  that has the specified x-coordinate, y-coordinate, width, and height.
        /// </summary>
        /// <param name="x">The x-coordinate of the top-left corner of the rectangle.</param>
        /// <param name="y">The y-coordinate of the top-left corner of the rectangle.</param>
        /// <param name="width">The width of the rectangle.</param>
        /// <param name="height">The height of the rectangle.</param>
        public Rect(double? x, double? y, double? width, double? height)
        {
            if (x == null || y == null)
            {
                x = y = double.MaxValue;
                width = height = 0;
            }
            else
            {
                if (width == null)
                {
                    width = 0;
                }
                if (height == null)
                {
                    height = 0;
                }
            }
            this.X = x.Value;
            this.Y = y.Value;
            this.Width = width.Value;
            this.Height = height.Value;
        }

        /// <summary>
        /// Gets the x-axis value of the left side of the rectangle.
        /// </summary>
        public double Left
        {
            get => this.X;
        }

        /// <summary>
        /// Gets the x-axis value of the right side of the rectangle.
        /// </summary>
        public double Right
        {
            get => this.X + this.Width;
        }

        /// <summary>
        /// Gets the y-axis position of the top of the rectangle.
        /// </summary>
        public double Top
        {
            get => this.Y;
        }

        /// <summary>
        /// Gets the y-axis value of the bottom of the rectangle.
        /// </summary>
        public double Bottom
        {
            get => this.Y + this.Height;
        }

        /// <summary>
        /// Gets the position of the top-left corner of the rectangle.
        /// </summary>
        internal Point TopLeft
        {
            get => new Point { X = this.Left, Y = this.Top };
        }

        /// <summary>
        /// Gets the position of the top-right corner of the rectangle.
        /// </summary>
        internal Point TopRight
        {
            get => new Point { X = this.Right, Y = this.Top };
        }

        /// <summary>
        /// Gets or sets the position of the top-Center corner of the rectangle.
        /// </summary>
        internal Point TopCenter
        {
            get => new Point { X = this.X + this.Width / 2, Y = this.Top };
        }

        /// <summary>
        /// Gets or sets the position of the middle-left corner of the rectangle.
        /// </summary>
        internal Point MiddleLeft
        {
            get => new Point { X = this.Left, Y = this.Y + this.Height / 2 };
        }

        /// <summary>
        /// Gets or sets the position of the middle-right corner of the rectangle.
        /// </summary>
        internal Point MiddleRight
        {
            get => new Point { X = this.Right, Y = this.Y + this.Height / 2 };
        }

        /// <summary>
        /// Gets or sets the position of the center of the rectangle.
        /// </summary>
        internal Point Center
        {
            get => new Point { X = this.X + this.Width / 2, Y = this.Y + this.Height / 2 };
        }

        /// <summary>
        /// Gets or sets the position of the bottom-left corner of the rectangle.
        /// </summary>
        internal Point BottomLeft
        {
            get => new Point { X = this.Left, Y = this.Bottom };
        }

        /// <summary>
        /// Gets or sets the position of the bottom-right corner of the rectangle.
        /// </summary>
        internal Point BottomRight
        {
            get => new Point { X = this.Right, Y = this.Bottom };
        }

        /// <summary>
        /// Gets or sets the position of the bottom-center corner of the rectangle.
        /// </summary>
        internal Point BottomCenter
        {
            get => new Point { X = this.X + this.Width / 2, Y = this.Bottom };
        }

        internal bool ContainsPoint(Point point, double padding = 0)
        {
            return this.X - padding <= point.X && (this.X + this.Width) + padding >= point.X
            && this.Y - padding <= point.Y && (this.Y + this.Height) + padding >= point.Y;
        }

        internal void UnitePoint(Point point)
        {
            if (this.X == double.MaxValue)
            {
                this.X = point.X;
                this.Y = point.Y;
                return;
            }
            double x = Math.Min(this.Left, point.X);
            double y = Math.Min(this.Top, point.Y);
            double right = Math.Max(this.Right, point.X);
            double bottom = Math.Max(this.Bottom, point.Y);
            this.X = x;
            this.Y = y;
            this.Width = right - this.X;
            this.Height = bottom - this.Y;
        }

        internal static Rect ToBounds(List<Point> points)
        {
            Rect rect = new Rect(); int i;
            for (i = 0; i < points.Count; i++)
            {
                rect.UnitePoint(points[i]);
            }
            return rect;
        }

        internal static bool Equals(Rect rect1, Rect rect2)
        {
            return rect1.X == rect2.X && rect1.Y == rect2.Y && rect1.Width == rect2.Width && rect1.Height == rect2.Height;
        }
        internal Rect UniteRect(Rect rect)
        {
            double right = Math.Max((double.NaN == this.Right || this.X == double.MaxValue) ? rect.Right : this.Right, rect.Right);
            double bottom = Math.Max((double.NaN == this.Bottom || this.Y == double.MaxValue) ? rect.Bottom : this.Bottom, rect.Bottom);
            this.X = Math.Min(this.Left, rect.Left);
            this.Y = Math.Min(this.Top, rect.Top);
            this.Width = right - this.X;
            this.Height = bottom - this.Y;
            return this;
        }

        internal Rect Inflate(double padding)
        {
            this.X -= padding;
            this.Y -= padding;
            this.Width += padding * 2;
            this.Height += padding * 2;
            return this;
        }

        internal bool Intersects(Rect rect)
        {
            if (this.Right < rect.Left || this.Left > rect.Right || this.Top > rect.Bottom || this.Bottom < rect.Top)
            {
                return false;
            }
            return true;
        }
        internal bool ContainsRect(Rect rect)
        {
            return this.Left <= rect.Left && this.Right >= rect.Right && this.Top <= rect.Top && this.Bottom >= rect.Bottom;
        }
        public object Clone()
        {
            return new Rect(this);
        }

    }
}