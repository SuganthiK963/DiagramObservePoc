using Syncfusion.Blazor.Diagram.Internal;
using System;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the Canvas that is used to define a plane(canvas) and to arrange the children based on margin.
    /// </summary>
    public class Canvas : Container
    {

    }
}