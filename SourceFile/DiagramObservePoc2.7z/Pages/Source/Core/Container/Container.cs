using Syncfusion.Blazor.Diagram.Internal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the Container that is used to group related objects.
    /// </summary>
    public class Container : DiagramElement
    {
        private Rect DesiredBounds { get; set; }
        internal bool MeasureChildren { get; set; } = true;
        internal double PrevRotateAngle { get; set; } = 0;
        /// <summary>
        /// Initializes a new instance of the <see cref="Container"/> class.
        /// </summary>
        /// <param name="src">group related objects.</param>
        public Container(Container src) : base(src)
        {
            PrevRotateAngle = src.PrevRotateAngle;
            MeasureChildren = src.MeasureChildren;
            DesiredBounds = src.DesiredBounds;
            Padding = src.Padding;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="Container"/> class.
        /// </summary>
        public Container() : base()
        {
        }
        /// <summary>
        /// Gets or sets the space between the container and its immediate children.
        /// </summary>
        public Thickness Padding = new Thickness() { Left = 0, Right = 0, Top = 0, Bottom = 0 };
        
        /// <summary>
        /// Gets or sets the collection of child elements.
        /// </summary>
        public ObservableCollection<ICommonElement> Children { get; set; } = new ObservableCollection<ICommonElement>();

        /// <summary>
        /// Returns a value indiciate whether the container has child elements or not
        /// </summary>
        internal bool HasChildren()
        {
            return this.Children != null && this.Children.Count > 0;
        }
       public override object Clone()
        {
            return new Container(this);
        }
    }
}