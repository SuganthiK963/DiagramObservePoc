using Syncfusion.Blazor.Diagram.Internal;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the class that defines the styles and types to arrange objects in containers.
    /// </summary>
    public class Thickness : DiagramObject
    {

        private double _left { get; set; }
        private double _right { get; set; }
        private double _top { get; set; }
        private double _bottom { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="TextElement"/> class.
        /// </summary>
        /// <param name="src">Thickness.</param>
        public Thickness(Thickness src) : base(src)
        {
            _left = src._left;
            _right = src._right;
            _top = src._top;
            _bottom = src._bottom;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="TextElement"/> class.
        /// </summary>
        public Thickness() : base()
        {

        }
        /// <summary>
        /// Gets or sets the left value of the thickness.
        /// </summary>
        [JsonPropertyName("left")]
        public double Left
        {
            get
            {
                return _left;
            }
            set
            {
                if (_left != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Left), value, _left, this);
                    _left = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the right value of the thickness.
        /// </summary>
        [JsonPropertyName("right")]
        public double Right
        {
            get
            {
                return _right;
            }
            set
            {
                if (_right != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Right), value, _right, this);
                    _right = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the top value of the thickness.
        /// </summary>
        [JsonPropertyName("top")]
        public double Top
        {
            get
            {
                return _top;
            }
            set
            {
                if (_top != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Top), value, _top, this);
                    _top = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the bottom value of the thickness.
        /// </summary>
        [JsonPropertyName("bottom")]
        public double Bottom
        {
            get
            {
                return _bottom;
            }
            set
            {
                if (_bottom != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Bottom), value, _bottom, this);
                    _bottom = value;
                }
            }
        }
        public override object Clone()
        {
            return new Thickness(this);
        }

    }
    /// <summary>
    /// Represents the class that defines the space to be left between an object and its immediate parent.
    /// </summary>
    public class Margin : DiagramObject
    {
        private double _bottom { get; set; }
        private double _left { get; set; }
        private double _right { get; set; }
        private double _top { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="Margin"/> class.
        /// </summary>
        /// <param name="src">Margin.</param>
        public Margin(Margin src) : base(src)
        {
            _bottom = src._bottom;
            _left = src._left;
            _right = src._right;
            _top = src._top;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="Margin"/> class.
        /// </summary>
        public Margin() : base()
        {

        }
        /// <summary>
        /// Gets or sets the space to be left from the bottom side of the parent of an element.
        /// </summary>
        [JsonPropertyName("bottom")]
        public double Bottom
        {
            get { return _bottom; }
            set
            {
                if (_bottom != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Bottom), value, _bottom, this);
                    _bottom = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the space to be left from the left side of the parent of an element.
        /// </summary>
        [JsonPropertyName("left")]
        public double Left
        {
            get { return _left; }
            set
            {
                if (_left != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Left), value, _left, this);
                    _left = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the space to be left from the right side of the parent of an element.
        /// </summary>
        [JsonPropertyName("right")]
        public double Right
        {
            get { return _right; }
            set
            {
                if (_right != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Right), value, _right, this);
                    _right = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the space to be left from the top side of the parent of an element.
        /// </summary>
        [JsonPropertyName("top")]
        public double Top
        {
            get { return _top; }
            set
            {
                if (_top != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Top), value, _top, this);
                    _top = value;
                }
            }
        }
        public override object Clone()
        {
            return new Margin(this);
        }
    }
    /// <summary>
    /// Represents the class that defines the Shadow appearance of the objects
    /// </summary>
    public class Shadow : DiagramObject
    {

        private double _angle { get; set; } = 45;
        private string _color { get; set; } = "lightgrey";
        private double _distance { get; set; } = 5;
        private double _opacity { get; set; } = 0.7;
        /// <summary>
        /// Initializes a new instance of the <see cref="Shadow"/> class.
        /// </summary>
        /// <param name="src">Shadow.</param>
        public Shadow(Shadow src) : base(src)
        {
            _angle = src._angle;
            _color = src._color;
            _distance = src._distance;
            _opacity = src._opacity;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="Shadow"/> class.
        /// </summary>
        public Shadow() : base()
        {

        }

        /// <summary>
        /// Gets or sets the Angle of the shadow. By default, it is 45.
        /// </summary>
        [JsonPropertyName("angle")]
        public double Angle
        {
            get { return _angle; }
            set
            {
                if (_angle != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Angle), value, _angle, this);
                    _angle = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the color of the shadow.
        /// </summary>
        [JsonPropertyName("color")]
        public string Color
        {
            get { return _color; }
            set
            {
                if (_color != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Color), value, _color, this);
                    _color = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the Distance of shadow. By default, it is 5px.
        /// </summary>
        [JsonPropertyName("distance")]
        public double Distance
        {
            get { return _distance; }
            set
            {
                if (_distance != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Distance), value, _distance, this);
                    _distance = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the Opacity of shadow. The opacity value ranges from 0 to 1.  By default, it is 0.7.
        /// </summary>
        [JsonPropertyName("opacity")]
        public double Opacity
        {
            get { return _opacity; }
            set
            {
                if (_opacity != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Opacity), value, _opacity, this);
                    _opacity = value;
                }
            }
        }
        public override object Clone()
        {
            return new Shadow(this);
        }

    }
    /// <summary>
    /// Represents the class that defines the different colors and the region of color transitions.
    /// </summary>
    public partial class GradientStop : DiagramObject
    {
        private string _color = string.Empty;
        private double? _offset = 0.0;
        private double _opacity = 1.0;
        /// <summary>
        /// Initializes a new instance of the <see cref="GradientStop"/> class.
        /// </summary>
        /// <param name="src">GradientStop.</param>
        public GradientStop(GradientStop src) : base(src)
        {
            _color = src._color;
            _offset = src._offset;
            _opacity = src._opacity;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="GradientStop"/> class.
        /// </summary>
        public GradientStop() : base()
        {

        }

        /// <summary>
        /// Gets or sets the color to be filled over the specified region.
        /// </summary>
        [JsonPropertyName("color")]
        public string Color
        {
            get { return _color; }
            set
            {
                if (_color != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Color), value, _color, this);
                    _color = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the position where the previous color transition ends, and a new color transition starts.  
        /// </summary>
        [JsonPropertyName("offset")]
        public double? Offset
        {
            get { return _offset; }
            set
            {
                if (_offset != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Offset), value, _offset, this);
                    _offset = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the transparency level of the region.  
        /// </summary>
        [JsonPropertyName("opacity")]
        public double Opacity
        {
            get { return _opacity; }
            set
            {
                if (_opacity != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Opacity), value, _opacity, this);
                    _opacity = value;
                }
            }
        }
        public override object Clone()
        {
            return new GradientStop(this);
        }
    }

    /// <summary>
    /// Represents the class that defines the appearance of text.
    /// </summary>
    public class TextShapeStyle : ShapeStyle
    {

        private bool _bold { get; set; }
        private string _color { get; set; } = "black";
        private string _fontFamily { get; set; } = "Arial";
        private double _fontSize { get; set; } = 12.0;
        private bool _italic { get; set; }
        private TextAlign _textAlign { get; set; } = TextAlign.Center;
        private TextDecoration _textDecoration { get; set; } = TextDecoration.None;
        private TextOverflow _textOverflow { get; set; } = TextOverflow.Wrap;
        private TextWrap _textWrapping { get; set; } = TextWrap.WrapWithOverflow;
        private WhiteSpace _whiteSpace { get; set; } = WhiteSpace.CollapseSpace;
        /// <summary>
        /// Initializes a new instance of the <see cref="TextShapeStyle"/> class.
        /// </summary>
        public TextShapeStyle() : base()
        {
            Fill = "transparent";
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="TextShapeStyle"/> class.
        /// </summary>
        /// <param name="src">TextShapeStyle.</param>
        public TextShapeStyle(TextShapeStyle src) : base(src)
        {
            _bold = src._bold;
            _color = src._color;
            _fontFamily = src._fontFamily;
            _fontSize = src._fontSize;
            _italic = src._italic;
            _textAlign = src._textAlign;
            _textDecoration = src._textDecoration;
            _textOverflow = src._textOverflow;
            _textWrapping = src._textWrapping;
            _whiteSpace = src._whiteSpace;

        }

        /// <summary>
        /// Gets or sets the users to enable or disable the bold style of a text.
        /// </summary>
        [JsonPropertyName("bold")]
        public bool Bold
        {
            get { return _bold; }
            set
            {
                if (_bold != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Bold), value, _bold, this);
                    }
                    _bold = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the font color of a text.
        /// </summary>
        [JsonPropertyName("color")]
        public string Color
        {
            get { return _color; }
            set
            {
                if (_color != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Color), value, _color, this);
                    _color = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the font type of a text.
        /// </summary>
        [JsonPropertyName("fontFamily")]
        public string FontFamily
        {
            get { return _fontFamily; }
            set
            {
                if (_fontFamily != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(FontFamily), value, _fontFamily, this);
                    }
                    _fontFamily = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the font size of a text.
        /// </summary>
        [JsonPropertyName("fontSize")]
        public double FontSize
        {
            get { return _fontSize; }
            set
            {
                if (_fontSize != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(FontSize), value, _fontSize, this);
                    }
                    _fontSize = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the users to enable or disable the italic style of a text.
        /// </summary>
        [JsonPropertyName("italic")]
        public bool Italic
        {
            get { return _italic; }
            set
            {
                if (_italic != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Italic), value, _italic, this);
                    }
                    _italic = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the alignment of the text inside the node bounds. By default, it's set to center.
        /// </summary>
        [JsonPropertyName("textAlign")]
        public TextAlign TextAlign
        {
            get { return _textAlign; }
            set
            {
                if (_textAlign != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(TextAlign), value, _textAlign, this);
                    }
                    _textAlign = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets how the text should be decorated.
        /// </summary>
        [JsonPropertyName("textDecoration")]
        public TextDecoration TextDecoration
        {
            get { return _textDecoration; }
            set
            {
                if (_textDecoration != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(TextDecoration), value, _textDecoration, this);
                    }
                    _textDecoration = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets how to handle the text when it exceeds the given size. By default, it's set to Wrap.
        /// </summary>
        [JsonPropertyName("textOverflow")]
        public TextOverflow TextOverflow
        {
            get { return _textOverflow; }
            set
            {
                if (_textOverflow != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(TextOverflow), value, _textWrapping, this);
                    }
                    _textOverflow = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets how the text should be wrapped when the text size exceeds some specific bounds. By default, its set to WrapWithOverflow.
        /// </summary>
        [JsonPropertyName("textWrapping")]
        public TextWrap TextWrapping
        {
            get { return _textWrapping; }
            set
            {
                if (_textWrapping != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(TextWrapping), value, _textWrapping, this);
                    }
                    _textWrapping = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets how to white space and new line characters must be handled. By default, it's set to CollapseSpace.
        /// </summary>
        [JsonPropertyName("whiteSpace")]
        public WhiteSpace WhiteSpace
        {
            get { return _whiteSpace; }
            set
            {
                if (_whiteSpace != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(WhiteSpace), value, _whiteSpace, this);
                    _whiteSpace = value;
                }
            }
        }
        public override object Clone()
        {
            return new TextShapeStyle(this);
        }

    }
    /// <summary>
    /// Represents the class that defines the style of shape/path.
    /// </summary>
    public class ShapeStyle : DiagramObject
    {

        private string _fill { get; set; } = "white";
        private double _opacity { get; set; } = 1.0;
        private string _strokeColor { get; set; } = "black";
        private string _strokeDashArray { get; set; } = "";
        private double _strokeWidth { get; set; } = 1.0;
        /// <summary>
        /// Initializes a new instance of the <see cref="ShapeStyle"/> class.
        /// </summary>
        public ShapeStyle() : base()
        {

        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ShapeStyle"/> class.
        /// </summary>
        /// <param name="src">ShapeStyle.</param>
        public ShapeStyle(ShapeStyle src) : base(src)
        {
            _fill = src._fill;
            _opacity = src._opacity;
            _strokeColor = src._strokeColor;
            _strokeDashArray = src._strokeDashArray;
            _strokeWidth = src.StrokeWidth;
        }

        /// <summary>
        /// Gets or sets the fill color of the shape or path.
        /// </summary>
        [JsonPropertyName("fill")]
        public string Fill
        {
            get { return _fill; }
            set
            {
                if (_fill != value)
                {
                    if (Parent != null)
                    {
                        if (Parent is Annotation)
                            (Parent as Annotation).isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Fill), value, _fill, this);
                    }
                    _fill = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the transparency level of the diagram elements. By default, it's set to 1.
        /// </summary>
        [JsonPropertyName("opacity")]
        public double Opacity
        {
            get { return _opacity; }
            set
            {
                if (_opacity != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Opacity), value, _opacity, this);
                    _opacity = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the stroke color of the diagram elements.
        /// </summary>
        [JsonPropertyName("strokeColor")]
        public string StrokeColor
        {
            get { return _strokeColor; }
            set
            {
                if (_strokeColor != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(StrokeColor), value, _strokeColor, this);
                    _strokeColor = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the pattern of dashes and space to the stroke of the diagram elements.
        /// </summary>
        [JsonPropertyName("strokeDashArray")]
        public string StrokeDashArray
        {
            get { return _strokeDashArray; }
            set
            {
                if (_strokeDashArray != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(StrokeDashArray), value, _strokeDashArray, this);
                    _strokeDashArray = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the width to the stroke of the diagram elements.
        /// </summary>
        [JsonPropertyName("strokeWidth")]
        public double StrokeWidth
        {
            get { return _strokeWidth; }
            set
            {
                if (_strokeWidth != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(StrokeWidth), value, _strokeWidth, this);
                    _strokeWidth = value;
                }
            }
        }
        public override object Clone()
        {
            return new ShapeStyle(this);
        }
    }
}