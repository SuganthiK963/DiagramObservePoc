﻿
using Syncfusion.Blazor.Diagram.Internal;

namespace Syncfusion.Blazor.Diagram
{
    public abstract class ICommonElement
    {
        private Point _position { get; set; } = null;
        private UnitMode? _unitModeValue { get; set; } = null;
        private Rect _floatingBounds { get; set; } = null;
        internal bool Float { get; set; } = false;
        internal bool PreventContainer { get; set; } = false;

        /// <summary>
        /// Gets or sets the corners of the rectangular bounds.
        /// </summary>
        internal Corners Corners { get; set; }

        internal bool IsCalculateDesiredSize { get; set; } = true;
        /// <summary>
        /// Gets or sets the offset values for container in flipping.
        /// </summary>
        internal Point FlipOffset { get; set; } = new Point() { X = 0, Y = 0 };

        /// <summary>
        /// Defines whether the element is group or port
        /// </summary>
        internal ElementAction ElementActions { get; set; } = ElementAction.None;

        internal bool InversedAlignment { get; set; } = true;
        /// <summary>
        /// Set to true during print and export
        /// </summary>
        internal bool IsExport { get; set; } = false;

        /// <summary>
        /// Set scaling value for print and export
        /// </summary>
        internal Point ExportScaleValue { get; set; } = new Point { X = 0, Y = 0 };

        /// <summary>
        /// Set scaling value for print and export
        /// </summary>
        internal Point ExportScaleOffset = new Point() { X = 0, Y = 0 };

        /// <summary>
        /// Check whether style need to be apply or not
        /// </summary>
        internal bool CanApplyStyle { get; set; } = true;

        /// <summary>
        /// Gets or sets the unique id of the element.
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// Gets or sets the reference point of the element.
        /// </summary>
        public Point Pivot { get; set; } = new Point() { X = 0.5, Y = 0.5 };

        /// <summary>
        /// Gets or sets whether the content of the element needs to be measured.
        /// </summary>
        protected bool IsDirt { get; set; } = true;
        /// <summary>
        /// Gets or sets whether the content of the element to be visible.
        /// </summary>
        public bool Visible { get; set; } = true;

        /// <summary>
        /// Gets or sets the x-coordinate of the element.
        /// </summary>
        public double OffsetX { get; set; } = 0;

        /// <summary>
        /// Gets or sets the y-coordinate of the element.
        /// </summary>
        public double OffsetY { get; set; } = 0;

        /// <summary>
        /// Gets or sets the corner of the element.
        /// </summary>
        public double CornerRadius { get; set; } = 0;

        /// <summary>
        /// Sets/Gets the minimum height of the element.
        /// </summary>
        public double? MinHeight { get; set; } = null;

        /// <summary>
        /// Gets or sets the minimum width of the element.
        /// </summary>
        public double? MinWidth { get; set; } = null;

        /// <summary>
        /// Sets/Gets the maximum width of the element.
        /// </summary>
        public double? MaxWidth { get; set; } = null;

        /// <summary>
        /// Gets or sets the maximum height of the element.
        /// </summary>
        public double? MaxHeight { get; set; } = null;

        /// <summary>
        /// Gets or sets the width of the element.
        /// </summary>
        public double? Width { get; set; } = null;

        /// <summary>
        /// Gets or sets the height of the element.
        /// </summary>
        public double? Height { get; set; } = null;

        /// <summary>
        /// Gets or sets the rotate angle of the element.
        /// </summary>
        public double RotateAngle { get; set; } = 0;

        /// <summary>
        /// Gets or sets the margin of the element.
        /// </summary>
        public Margin Margin { get; set; } = new Margin { Left = 0, Right = 0, Top = 0, Bottom = 0 };

        /// <summary>
        /// Gets or sets how the element has to be horizontally arranged with respect to its immediate parent.
        /// </summary>
        public HorizontalAlignment HorizontalAlignment { get; set; } = HorizontalAlignment.Auto;

        /// <summary>
        /// Gets or sets how the element has to be vertically arranged with respect to its immediate parent.
        /// </summary>
        public VerticalAlignment VerticalAlignment { get; set; } = VerticalAlignment.Auto;


        /// <summary>
        /// Gets or sets whether the element has to be aligned with respect to a point/with respect to its immediate parent.
        /// </summary>
        public RelativeMode RelativeMode { get; set; } = RelativeMode.Point;

        /// <summary>
        /// Gets or sets whether the element has to be transformed based on its parent or not.
        /// </summary>
        public Transform Transform { get; set; } = Transform.Self | Transform.Parent;

        /// <summary>
        /// Gets or sets the style of the element
        /// </summary>
        public ShapeStyle Style { get; set; } = new ShapeStyle() { Fill = "white", StrokeColor = "black", Opacity = 1, StrokeWidth = 1 };

        /// <summary>
        /// Gets or sets the parent id for the element.
        /// </summary>
        public string ParentId { get; set; }

        /// <summary>
        /// Gets or sets the minimum size that is required by the element.
        /// </summary>
        public Size DesiredSize { get; set; } = new Size();

        /// <summary>
        /// Gets or sets the size that the element will be rendered.
        /// </summary>
        public Size ActualSize { get; set; } = new Size();

        /// <summary>
        /// Gets or sets the rotate angle that is set to the immediate parent of the element.
        /// </summary>
        public double ParentTransform { get; set; } = 0;
        /// <summary>
        /// Gets or sets the boolean value for the element.
        /// </summary>
        public bool IsSvgRender { get; set; } = false;

        /// <summary>
        /// Gets or sets the boundary of the element.
        /// </summary>
        public Rect Bounds { get; set; } = new Rect();

        /// <summary>
        /// Defines the appearance of the shadow of the element.
        /// </summary>
        public Shadow Shadow { get; set; } = null;

        /// <summary>
        /// Defines the description of the diagram element.
        /// </summary>
        public string Description { get; set; } = "";

        /// <summary>
        /// Defines whether the element has to be measured or not.
        /// </summary>
        public bool StaticSize { get; set; } = false;

        /// <summary>
        /// Check whether the element is rect or not.
        /// </summary>
        public bool IsRectElement { get; set; } = false;
        /// <summary>
        /// Gets or sets the outer bounds of the element.
        /// </summary>
        public Rect OuterBounds
        {
            get
            {
                if (this._floatingBounds != null)
                {
                    return this._floatingBounds;
                }
                else { return this.Bounds; }
            }
            set
            {
                if (this._floatingBounds != value)
                {
                    this._floatingBounds = value;
                }
            }
        }

        internal virtual Size Measure(Size availableSize)
        {
            return availableSize;
        }
        internal virtual Size Arrange(Size desiredSize, bool? isStack)
        {
            return desiredSize;
        }
        /// <summary>
        /// Sets the offset of the element with respect to its parent.
        /// </summary>
        public void SetOffsetWithRespectToBounds(double x, double y, UnitMode mode)
        {
            _unitModeValue = mode;
            _position = new Point { X = x, Y = y };
        }
    }


    /// <summary>
    /// Define the Corners class.
    /// </summary>
    internal class Corners
    {
        /// <summary>
        /// Gets or sets the top left point of canvas corner
        /// </summary>
        internal Point TopLeft { get; set; }
        /// <summary>
        /// Gets or sets the top center point of canvas corner
        /// </summary>
        internal Point TopCenter { get; set; }
        /// <summary>
        /// Gets or sets the top right point of canvas corner.
        /// </summary>
        internal Point TopRight { get; set; }
        /// <summary>
        /// Gets or sets the middle left point of canvas corner.
        /// </summary>
        internal Point MiddleLeft { get; set; }
        /// <summary>
        /// Gets or sets the center point of canvas corner.
        /// </summary>
        internal Point Center { get; set; }
        /// <summary>
        /// Gets or sets the middle left point of canvas corner.
        /// </summary>
        internal Point MiddleRight { get; set; }
        /// <summary>
        /// Gets or sets the bottom left point of canvas corner.
        /// </summary>
        internal Point BottomLeft { get; set; }
        /// <summary>
        /// Gets or sets the bottom center point of canvas corner.
        /// </summary>
        internal Point BottomCenter { get; set; }
        /// <summary>
        /// Gets or sets the bottom right point of canvas corner.
        /// </summary>
        internal Point BottomRight { get; set; }
        /// <summary>
        /// Gets or sets the left position of canvas corner.
        /// </summary>
        public double Left { get; set; }
        /// <summary>
        /// Gets or sets the right position of canvas corner.
        /// </summary>
        public double Right { get; set; }
        /// <summary>
        /// Gets or sets the top position of canvas corner.
        /// </summary>
        public double Top { get; set; }
        /// <summary>
        /// Gets or sets the bottom position of canvas corner.
        /// </summary>
        public double Bottom { get; set; }
        /// <summary>
        /// Gets or sets the width of canvas.
        /// </summary>
        public double Width { get; set; }
        /// <summary>
        /// Gets or sets height of canvas.
        /// </summary>
        public double Height { get; set; }
    }

}
