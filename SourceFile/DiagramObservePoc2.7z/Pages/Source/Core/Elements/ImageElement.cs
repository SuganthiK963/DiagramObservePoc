﻿using Syncfusion.Blazor.Diagram.Internal;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the class that defines a basic image elements.
    /// </summary>
    public class ImageElement : DiagramElement
    {

        private string _imageSource;
        /// <summary>
        /// Initializes a new instance of the <see cref="ImageElement"/> class.
        /// </summary>
        /// <param name="src">basic image element.</param>
        public ImageElement(ImageElement src) : base(src)
        {
            _imageSource = src._imageSource;
            Stretch = src.Stretch;
            ImageScale = src.ImageScale;
            ImageAlign = src.ImageAlign;
            ContentSize = src.ContentSize;
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ImageElement"/> class.
        /// </summary>
        public ImageElement() : base()
        {
        }

        /// <summary>
        /// Gets or sets the source of the image element.
        /// </summary>
        [JsonPropertyName("source")]
        public string Source
        {
            get
            {
                return this._imageSource;
            }
            set
            {
                if (this._imageSource != value)
                {
                    this._imageSource = value;
                    this.IsDirt = true;
                }
            }
        }
        /// <summary>
        /// Gets or sets the scaling factor of the image.
        /// </summary>
        public Scale ImageScale { get; set; } = Scale.None;
        /// <summary>
        /// Gets or sets the alignment of the image.
        /// </summary>
        public ImageAlignment ImageAlign { get; set; } = ImageAlignment.None;
        /// <summary>
        /// Gets or sets image element, which determines how content fits into the available space.
        /// </summary>
        public Stretch Stretch { get; set; } = Stretch.Stretch;
        /// <summary>
        /// Gets or sets the actual size of the image.
        /// </summary>
        public Size ContentSize { get; set; }

        public override object Clone()
        {
            return new ImageElement(this);
        }

    }
}
