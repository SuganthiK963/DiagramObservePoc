﻿namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the HTMLElement thast defines the basic html elements.
    /// </summary>
    public class DiagramHtmlElement : DiagramElement
    {
    }
}
