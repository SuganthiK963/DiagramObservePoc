using Syncfusion.Blazor.Diagram.Internal;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the class which defines how to align the path based on offsetX and offsetY.
    /// </summary>
    public class PathElement : DiagramElement
    {
        private object _pointTimer { get; set; }
        private string _pathData { get; set; } = string.Empty;
        [JsonIgnore]
        internal List<Point> Points { get; set; } = new List<Point>() { };
        [JsonIgnore]
        internal bool CanMeasurePath { get; set; }
        [JsonIgnore]
        internal bool IsBpmnSequenceDefault { get; set; } = false;
        [JsonIgnore]
        internal Rect AbsoluteBounds { get; set; } = new Rect();
        /// <summary>
        /// Initializes a new instance of the <see cref="PathElement"/> class.
        /// </summary>
        /// <param name="src">path element.</param>
        public PathElement(PathElement src) : base(src)
        {
            _pathData = src._pathData;
            CanMeasurePath = src.CanMeasurePath;
            IsBpmnSequenceDefault = src.IsBpmnSequenceDefault;
            if (src.AbsoluteBounds != null)
            {
                AbsoluteBounds = src.AbsoluteBounds.Clone() as Rect;
            }
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="PathElement"/> class.
        /// </summary>
        public PathElement() : base()
        {
        }
        /// <summary>
        /// Gets or sets the geometry of the path element.
        /// </summary>
        [JsonPropertyName("data")]
        public string Data
        {
            get
            {
                return this._pathData;
            }
            set
            {
                if (this._pathData != value)
                {
                    this._pathData = value;
                    this.IsDirt = true;
                }
            }

        }
        /// <summary>
        /// Gets or sets whether the path has to be transformed to fit the given x,y, width, height.
        /// </summary>
        [JsonPropertyName("transformPath")]
        public bool TransformPath { get; set; } = true;

        /// <summary>
        /// Gets or sets the equivalent path, that will have the origin as 0,0.
        /// </summary>
        [JsonPropertyName("absolutePath")]
        public string AbsolutePath { get; set; } = string.Empty;

        public override object Clone()
        {
            return new PathElement(this);
        }
    }
}