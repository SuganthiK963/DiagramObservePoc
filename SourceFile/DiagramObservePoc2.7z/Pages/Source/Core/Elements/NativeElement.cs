﻿namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the class which defines the basic native elements.
    /// </summary>
    public class DiagramNativeElement : DiagramElement
    {

    }
}
