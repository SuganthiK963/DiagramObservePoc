using Syncfusion.Blazor.Diagram.Internal;
using System;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represent the diagram element that defines the basic unit of diagram.
    /// </summary>
    public class DiagramElement : ICommonElement
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DiagramElement"/> class.
        /// </summary>
        /// <param name="src">basic unit of diagram.</param>
        public DiagramElement(DiagramElement src)
        {
            Float = src.Float;
            PreventContainer = src.PreventContainer;
            OffsetX = src.OffsetX;
            OffsetY = src.OffsetY;
            InversedAlignment = src.InversedAlignment;
            IsExport = src.IsExport;
            ID = src.ID;
            Visible = src.Visible;
            CornerRadius = src.CornerRadius;
            MinHeight = src.MinHeight;
            MinWidth = src.MinWidth;
            MaxWidth = src.MaxWidth;
            MaxHeight = src.MaxHeight;
            Width = src.Width;
            Height = src.Height;
            RotateAngle = src.RotateAngle;
            if (src.Margin != null)
            {
                Margin = src.Margin.Clone() as Margin;
            }
            HorizontalAlignment = src.HorizontalAlignment;
            VerticalAlignment = src.VerticalAlignment;
            RelativeMode = src.RelativeMode;
            Transform = src.Transform;
            if (src.Style != null)
            {
                Style = src.Style.Clone() as ShapeStyle;
            }
            ParentId = src.ParentId;
            DesiredSize = src.DesiredSize;
            ActualSize = src.ActualSize;
            ParentTransform = src.ParentTransform;
            IsSvgRender = src.IsSvgRender;
            Description = src.Description;
            StaticSize = src.StaticSize;
            IsRectElement = src.IsRectElement;
            if (src.Shadow != null)
            {
                Shadow = src.Shadow.Clone() as Shadow;
            }
            if (src.Bounds != null)
            {
                Bounds = src.Bounds.Clone() as Rect;
            }
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="DiagramElement"/> class.
        /// </summary>
        public DiagramElement()
        {
            //ID = BaseUtil.RandomId();
        }
        
        public virtual object Clone()
        {
            return new DiagramElement(this);
        }

    }
}