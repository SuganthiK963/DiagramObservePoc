﻿using System;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the class that is derived from <see cref="ICloneable"/> interface.
    /// </summary>
    public interface IDiagramObject : ICloneable
    {
        /// <summary>
        /// Invoked whenever the effective value of any property on this diagram objects has been updated.
        /// </summary>
        void UpdatePropertyChanged(string propertyName, object newVal, object oldVal, IDiagramObject container);
    }
}
