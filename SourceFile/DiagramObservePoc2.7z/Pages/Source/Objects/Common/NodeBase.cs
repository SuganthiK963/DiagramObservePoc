﻿using Syncfusion.Blazor.Diagram.Internal;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Represents the class that defines the common behavior of nodes, connectors and groups.
    /// </summary>
    public class NodeBase : DiagramObject
    {
        private string id { get; set; }
        private int zIndex { get; set; } = -1;
        private Margin margin { get; set; } = new Margin();
        private bool visible { get; set; } = true;
        [JsonIgnore]
        internal bool excludeFromLayout { get; set; } = false;
        private Dictionary<string, object> addInfo { get; set; } = new Dictionary<string, object>();
        private FlipDirection flip { get; set; } = FlipDirection.None;
        private Container wrapper { get; set; }
        [JsonIgnore]
        internal string ParentId { get; set; } = string.Empty;
        /// <summary>
        /// Initializes a new instance of the <see cref="NodeBase"/> class.
        /// </summary>
        /// <param name="src">NodeBase</param>
        public NodeBase(NodeBase src) : base(src)
        {
            //id = string.IsNullOrEmpty(src.ID) ? BaseUtil.RandomId() : src.ID;
            zIndex = src.zIndex;
            if (src.margin != null)
            {
                margin = src.margin.Clone() as Margin;
            }
            visible = src.visible;
            excludeFromLayout = src.excludeFromLayout;
            flip = src.flip;
            ParentId = src.ParentId;
            addInfo = new Dictionary<string, object>(src.addInfo);
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="NodeBase"/> class.
        /// </summary>
        public NodeBase() : base()
        {
            //id = BaseUtil.RandomId();
        }
        /// <summary>
        /// Gets or sets the unique id of diagram objects.
        /// </summary>
        [JsonPropertyName("id")]
        public string ID
        {
            get
            {
                return id;
            }
            set
            {
                if (id != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(ID), value, id, this);
                    id = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the UI of a node/connector.
        /// </summary>
        [JsonIgnore]
        internal Container Wrapper
        {
            get { return wrapper; }
            set
            {
                if (wrapper != value)
                {
                    wrapper = value;
                }
            }
        }
        /// <summary>
        /// Gets or sets the visual order of the node/connector.
        /// </summary>
        [JsonPropertyName("zIndex")]
        public int ZIndex
        {
            get
            {
                return zIndex;
            }
            set
            {
                if (zIndex != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(ZIndex), value, zIndex, this);
                    zIndex = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the space to be left between the node and its immediate parent.
        /// </summary>
        [JsonPropertyName("margin")]
        public Margin Margin
        {
            get
            {
                if (margin != null && margin.Parent == null)
                    margin.SetParent(this, nameof(Margin));
                return margin;
            }
            set
            {
                if (margin != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Margin), value, margin, this);
                    margin = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the visibility of the node/connector.
        /// </summary>
        [JsonPropertyName("visible")]
        public bool Visible
        {
            get { return visible; }
            set
            {
                if (visible != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Visible), value, visible, this);
                    visible = value;
                }
            }
        }
        /// <summary>
        /// Gets or sets the value indicates whether the node should be automatically positioned or not. Applicable, if layout option is enabled.
        /// </summary>
        [JsonPropertyName("excludeFromLayout")]
        public bool ExcludeFromLayout
        {
            get { return excludeFromLayout; }
            set
            {
                if (excludeFromLayout != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(ExcludeFromLayout), value, excludeFromLayout, this);
                    excludeFromLayout = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the user to save custom information/data about a node/connector
        /// </summary>
        [JsonPropertyName("addInfo")]
        public Dictionary<string, object> AddInfo
        {
            get { return addInfo; }
            set
            {
                if (addInfo != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(AddInfo), value, addInfo, this);
                    addInfo = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets a valeue to flip the element in Horizontal/Vertical directions.
        /// </summary>
        [JsonPropertyName("flip")]
        internal FlipDirection Flip
        {
            get { return flip; }
            set
            {
                if (flip != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Flip), value, flip, this);
                    flip = value;
                }
            }
        }
        public override object Clone()
        {
            return new NodeBase(this);
        }
    }
    /// <summary>
    /// Represents the class that define the base class for the diagram object.
    /// </summary>
    public class DiagramObject : IDiagramObject
    {
        [JsonIgnore]
        internal IDiagramObject Parent { get; set; }
        [JsonIgnore]
        internal string PropertyName { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="DiagramObject"/> class.
        /// </summary>
        public DiagramObject() : base()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="DiagramObject"/> class.
        /// </summary>
        /// <param name="src">DiagramObject</param>
        public DiagramObject(DiagramObject src)
        {
            Parent = src.Parent;
            PropertyName = src.PropertyName;
        }
        /// <summary>
        /// Invoked whenever the effective value of any property on this diagram objects has been updated.
        /// </summary>
        void IDiagramObject.UpdatePropertyChanged(string propertyName, object newVal, object oldVal, IDiagramObject container)
        {
            if (Parent != null)
            {
                Parent.UpdatePropertyChanged(propertyName, newVal, oldVal, container);
            }
        }
        /// <summary>
        /// Gets a parent of an object
        /// </summary>
        /// <returns>returns a parent of an object.</returns>
        public IDiagramObject GetParent()
        {
            return Parent;
        }
        internal void SetParent(IDiagramObject parentVal, string propertyName)
        {
            Parent = parentVal;
            PropertyName = propertyName;
        }
        public virtual object Clone()
        {
            return new DiagramObject(this);
        }

    }

    internal class PropertyChangeValues
    {
        internal object OldValue { get; set; }
        internal object NewValue { get; set; }
    }
}
