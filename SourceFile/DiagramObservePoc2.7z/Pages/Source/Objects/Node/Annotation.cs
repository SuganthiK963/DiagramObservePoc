﻿using Syncfusion.Blazor.Diagram.Internal;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{
    public class Hyperlink : DiagramObject
    {
        private string color { get; set; } = "blue";
        private string content { get; set; }
        private string link { get; set; }
        private TextDecoration textDecoration { get; set; } = TextDecoration.None;
        public Hyperlink(Hyperlink src) : base(src)
        {
            color = src.color;
            content = src.content;
            link = src.link;
            textDecoration = src.textDecoration;
        }
        public Hyperlink() : base()
        {
        }
        /// <summary>
        /// Gets or set the fill color of the hyperlink
        /// </summary>
        [JsonPropertyName("color")]
        public string Color
        {
            get { return color; }
            set
            {
                if (color != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Color), value, color, this);
                    color = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the content for hyperlink.
        /// </summary>
        [JsonPropertyName("content")]
        public string Content
        {
            get { return content; }
            set
            {
                if (content != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Content), value, content, this);
                    content = value;
                }
            }
        }
        /// <summary>
        /// Gets or sets the link for hyperlink.
        /// </summary>
        [JsonPropertyName("link")]
        public string Link
        {
            get { return link; }
            set
            {
                if (link != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Link), value, link, this);
                    link = value;
                }
            }
        }

        /// <summary>
        /// Defines how the link should be decorated. For example, with underline/over line
        /// </summary>
        [JsonPropertyName("textDecoration")]
        public TextDecoration TextDecoration
        {
            get { return textDecoration; }
            set
            {
                if (textDecoration != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(TextDecoration), value, textDecoration, this);
                    textDecoration = value;
                }
            }
        }
        public override object Clone()
        {
            return new Hyperlink(this);
        }
    }
    /// <summary>
    /// Defines the textual description of nodes/connectors
    /// </summary>
    public class Annotation : DiagramObject
    {
        private string id { get; set; }
        internal bool isDirtAnnotation { get; set; }
        private string content { get; set; } = string.Empty;
        private string template { get; set; }   //HTMLElement;
        private AnnotationType annotationType { get; set; } = AnnotationType.String;
        private bool visibility { get; set; } = true;
        private AnnotationConstraints constraints { get; set; } = AnnotationConstraints.InheritReadOnly;
        private Hyperlink hyperlink { get; set; }
        private double? width { get; set; }
        private double? height { get; set; }
        private double rotateAngle { get; set; } = 0;
        private HorizontalAlignment horizontalAlignment { get; set; } = HorizontalAlignment.Center;
        private VerticalAlignment verticalAlignment { get; set; } = VerticalAlignment.Center;
        private Margin margin { get; set; } = new Margin();
        private Margin dragLimit { get; set; } = new Margin();
        private AnnotationTypes type { get; set; } = AnnotationTypes.Shape;
        private object addInfo { get; set; }
        private TextShapeStyle style { get; set; } = new TextShapeStyle() { StrokeWidth = 0, StrokeColor = "transparent", Fill = "transparent" };
        public Annotation(Annotation src) : base(src)
        {
            //id = string.IsNullOrEmpty(src.ID) ? BaseUtil.RandomId() : src.ID;
            isDirtAnnotation = src.isDirtAnnotation;
            content = src.content;
            template = src.template;
            annotationType = src.annotationType;
            visibility = src.visibility;
            Constraints = src.constraints;
            if (src.hyperlink != null)
            {
                hyperlink = src.hyperlink.Clone() as Hyperlink;
            }
            width = src.width;
            height = src.height;
            rotateAngle = src.rotateAngle;
            horizontalAlignment = src.horizontalAlignment;
            verticalAlignment = src.verticalAlignment;
            if (src.margin != null)
            {
                margin = src.margin.Clone() as Margin;
            }
            if (src.dragLimit != null)
            {
                dragLimit = src.dragLimit.Clone() as Margin;
            }
            addInfo = src.addInfo;
            if (src.style != null)
            {
                style = src.style.Clone() as TextShapeStyle;
            };

        }
        public Annotation() : base()
        {
            //id = BaseUtil.RandomId();
        }
        /// <summary>
        /// Represents the unique id of diagram objects
        /// </summary>
        [JsonPropertyName("id")]
        public string ID
        {
            get
            {
                return id;
            }
            set
            {
                if (id != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(ID), value, id, this);
                    id = value;
                }
            }
        }

        /// <summary>
        /// Sets the textual description of the node/connector
        /// </summary>
        [JsonPropertyName("content")]
        public string Content
        {
            get { return content; }
            set
            {
                if (content != value)
                {
                    if (Parent != null)
                    {
                        isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Content), value, content, this);
                    }
                    content = value;
                }
            }
        }

        /// <summary>
        /// Sets the textual description of the node/connector
        /// </summary>
        [JsonPropertyName("template")]
        public string Template
        {
            get { return template; }
            set
            {
                if (template != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Template), value, template, this);
                    template = value;
                }
            }
        }

        /// <summary>
        /// Defines the type of annotation template
        /// </summary>
        [JsonPropertyName("annotationType")]
        public AnnotationType AnnotationType
        {
            get { return annotationType; }
            set
            {
                if (annotationType != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(AnnotationType), value, annotationType, this);
                    annotationType = value;
                }
            }
        }

        /// <summary>
        /// Defines the visibility of the label
        /// </summary>
        [JsonPropertyName("visibility")]
        public bool Visibility
        {
            get { return visibility; }
            set
            {
                if (visibility != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Visibility), value, visibility, this);
                    visibility = value;
                }
            }
        }
        /// <summary>
        /// Enables or disables the default behaviors of the label.
        /// </summary>
        [JsonPropertyName("constraints")]
        public AnnotationConstraints Constraints
        {
            get
            {
                return constraints;
            }
            set
            {
                if (constraints != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Constraints), value, constraints, this);
                    constraints = value;
                }
            }
        }

        /// <summary>
        /// Sets the hyperlink of the label
        /// </summary>
        [JsonPropertyName("hyperlink")]
        public Hyperlink Hyperlink
        {
            get
            {
                if (hyperlink != null && hyperlink.Parent == null)
                    hyperlink.SetParent(this, nameof(Hyperlink));
                return hyperlink;
            }
            set
            {
                if (hyperlink != value)
                {
                    if (Parent != null)
                    {
                        isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Hyperlink), value, hyperlink, this);
                    }
                    hyperlink = value;
                }
            }
        }
        /// <summary>
        /// Sets the width of the text
        /// </summary>
        [JsonPropertyName("width")]
        public double? Width
        {
            get { return width; }
            set
            {
                if (width != value)
                {
                    if (Parent != null)
                    {
                        isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Width), value, width, this);
                    }
                    width = value;
                }
            }
        }
        /// <summary>
        /// Sets the height of the text
        /// </summary>
        [JsonPropertyName("height")]
        public double? Height
        {
            get { return height; }
            set
            {
                if (height != value)
                {
                    if (Parent != null)
                    {
                        isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Height), value, height, this);
                    }
                    height = value;
                }
            }
        }

        /// <summary>
        /// Sets the rotate angle of the text
        /// </summary>
        [JsonPropertyName("rotateAngle")]
        public double RotateAngle
        {
            get { return rotateAngle; }
            set
            {
                if (rotateAngle != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(RotateAngle), value, rotateAngle, this);
                    rotateAngle = value;
                }
            }
        }

        /// <summary>
        /// Defines the appearance of the text
        /// </summary>
        [JsonPropertyName("style")]
        public TextShapeStyle Style
        {
            get
            {
                if (style != null && style.Parent == null)
                    style.SetParent(this, nameof(Style));
                return style;
            }
            set
            {
                if (style != value)
                {
                    if (Parent != null)
                    {
                        isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Style), value, style, this);
                    }
                    style = value;
                }
            }
        }

        /// <summary>
        /// Sets the horizontal alignment of the text with respect to the parent node/connector
        /// </summary>
        [JsonPropertyName("horizontalAlignment")]
        public HorizontalAlignment HorizontalAlignment
        {
            get { return horizontalAlignment; }
            set
            {
                if (horizontalAlignment != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(HorizontalAlignment), value, horizontalAlignment, this);
                    horizontalAlignment = value;
                }
            }
        }

        /// <summary>
        /// Sets the vertical alignment of the text with respect to the parent node/connector
        /// </summary>
        [JsonPropertyName("verticalAlignment")]
        public VerticalAlignment VerticalAlignment
        {
            get { return verticalAlignment; }
            set
            {
                if (verticalAlignment != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(VerticalAlignment), value, verticalAlignment, this);
                    verticalAlignment = value;
                }
            }
        }

        /// <summary>
        /// Sets the space to be left between an annotation and its parent node/connector
        /// </summary>
        [JsonPropertyName("margin")]
        public Margin Margin
        {
            get
            {
                if (margin != null && margin.Parent == null)
                    margin.SetParent(this, nameof(Margin));
                return margin;
            }
            set
            {
                if (margin != value)
                {
                    if (Parent != null)
                    {
                        isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Margin), value, margin, this);
                    }
                    margin = value;
                }
            }
        }
        /// <summary>
        /// Sets the space to be left between an annotation and its parent node/connector
        /// </summary>
        [JsonPropertyName("dragLimit")]
        internal Margin DragLimit
        {
            get
            {
                if (dragLimit != null && dragLimit.Parent == null)
                    dragLimit.SetParent(this, nameof(DragLimit));
                return dragLimit;
            }
            set
            {
                if (dragLimit != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(DragLimit), value, dragLimit, this);
                    dragLimit = value;
                }
            }
        }

        /// <summary>
        /// Sets the type of the annotation
        /// </summary>
        [JsonPropertyName("type")]
        public AnnotationTypes Type
        {
            get { return type; }
            set
            {
                if (type != value)
                {
                    if (Parent != null)
                    {
                        isDirtAnnotation = true;
                        Parent.UpdatePropertyChanged(nameof(Type), value, type, this);
                    }
                    type = value;
                }
            }
        }

        /// <summary>
        /// Allows the user to save custom information/data about an annotation
        /// </summary>
        [JsonPropertyName("addInfo")]
        public object AddInfo
        {
            get { return addInfo; }
            set
            {
                if (addInfo != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(AddInfo), value, addInfo, this);
                    addInfo = value;
                }
            }
        }
        public override object Clone()
        {
            return new Annotation(this);
        }
    }

    /// <summary>
    /// Defines the textual description of nodes/connectors with respect to bounds
    /// </summary>
    public class ShapeAnnotation : Annotation
    {
        private Point offset { get; set; } = new Point() { X = 0.5, Y = 0.5 };
        public ShapeAnnotation() : base()
        {
        }
        public ShapeAnnotation(ShapeAnnotation src) : base(src)
        {
            if (src.offset != null)
            {
                offset = src.offset.Clone() as Point;
            }
        }
        /// <summary>
        /// Sets the position of the annotation with respect to its parent bounds
        /// </summary>
        [JsonPropertyName("offset")]
        public Point Offset
        {
            get
            {

                if (offset != null && offset.Parent == null)
                    offset.SetParent(this, nameof(Offset));
                return offset;
            }
            set
            {
                if (offset != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Offset), value, offset, this);
                    offset = value;
                }
            }
        }
        public override object Clone()
        {
            return new ShapeAnnotation(this);
        }
    }
    /// <summary>
    /// Defines the connector annotation
    /// </summary>
    public class PathAnnotation : Annotation
    {
        private double offset { get; set; } = 0.5;
        private Point displacement { get; set; } = new Point();
        private AnnotationAlignment alignment { get; set; } = AnnotationAlignment.Center;
        private bool segmentAngle { get; set; } = false;
        public PathAnnotation(PathAnnotation src) : base(src)
        {
            offset = src.offset;
            displacement = src.displacement;
            alignment = src.alignment;
            segmentAngle = src.segmentAngle;
        }

        public PathAnnotation() : base()
        {
        }
        /// <summary>
        /// Sets the segment offset of annotation
        /// </summary>
        [JsonPropertyName("offset")]
        public double Offset
        {
            get { return offset; }
            set
            {
                if (offset != value)
                {
                    double oldValue = offset;
                    offset = value;
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Offset), value, oldValue, this);
                }
            }
        }
        /// <summary>
        /// Sets the displacement of an annotation from its actual position
        /// </summary>
        [JsonPropertyName("displacement")]
        public Point Displacement
        {
            get
            {
                if (displacement != null && displacement.Parent == null)
                    displacement.SetParent(this, nameof(Displacement));
                return displacement;
            }
            set
            {
                if (displacement != value)
                {
                    Point oldValue = displacement;
                    displacement = value;
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Displacement), value, oldValue, this);
                }
            }
        }
        /// <summary>
        /// Sets the segment alignment of annotation
        /// </summary>
        [JsonPropertyName("alignment")]
        public AnnotationAlignment Alignment
        {
            get { return alignment; }
            set
            {
                if (alignment != value)
                {
                    AnnotationAlignment oldValue = alignment;
                    alignment = value;
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Alignment), value, oldValue, this);
                    alignment = value;
                }
            }
        }

        /// <summary>
        /// Enable/Disable the angle based on the connector segment
        /// </summary>
        [JsonPropertyName("segmentAngle")]
        public bool SegmentAngle
        {
            get { return segmentAngle; }
            set
            {
                if (segmentAngle != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(SegmentAngle), value, segmentAngle, this);
                    segmentAngle = value;
                }
            }
        }
        public override object Clone()
        {
            return new PathAnnotation(this);
        }
    }
}