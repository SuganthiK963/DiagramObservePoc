﻿using Syncfusion.Blazor.Diagram.Internal;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{
    /**
 * Defines the behavior of connection ports
 */
    public class Port : DiagramObject
    {
        private string id { get; set; }
        private HorizontalAlignment horizontalAlignment { get; set; } = HorizontalAlignment.Center;
        private VerticalAlignment verticalAlignment { get; set; } = VerticalAlignment.Center;
        private Margin margin { get; set; } = new Margin();
        private double width { get; set; } = 12;
        private double height { get; set; } = 12;
        private ShapeStyle style { get; set; } = new ShapeStyle();
        private PortShapes shape { get; set; } = PortShapes.Square;
        private PortVisibility visibility { get; set; } = PortVisibility.Connect;
        private string pathData { get; set; }
        private PortConstraints constraints { get; set; } = PortConstraints.Default;
        private object addInfo { get; set; }
        private List<string> outEdges { get; set; } = new List<string>();
        private List<string> inEdges { get; set; } = new List<string>();
        public Port(Port src) : base(src)
        {
            //id = string.IsNullOrEmpty(src.ID) ? BaseUtil.RandomId() : src.ID;
            horizontalAlignment = src.horizontalAlignment;
            verticalAlignment = src.verticalAlignment;
            margin = src.margin;
            width = src.width;
            height = src.height;
            if (src.style != null)
            {
                style = src.style.Clone() as ShapeStyle;
            }
            shape = src.shape;
            visibility = src.visibility;
            pathData = src.pathData;
            constraints = src.constraints;
            addInfo = src.addInfo;
            outEdges = new List<string>();
            inEdges = new List<string>();

        }
        public Port() : base()
        {
            //id = BaseUtil.RandomId();
        }

        /// <summary>
        /// Represents the unique id of diagram objects
        /// </summary>
        [JsonPropertyName("id")]
        public string ID
        {
            get
            {
                return id;
            }
            set
            {
                if (id != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(ID), value, id, this);
                    id = value;
                }
            }
        }
        /// <summary>
        /// Sets the horizontal alignment of the port with respect to its immediate parent(node/connector)
        /// </summary>
        [JsonPropertyName("horizontalAlignment")]
        public HorizontalAlignment HorizontalAlignment
        {
            get { return horizontalAlignment; }
            set
            {
                if (horizontalAlignment != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(HorizontalAlignment), value, horizontalAlignment, this);
                    horizontalAlignment = value;
                }
            }
        }
        /// <summary>
        /// Sets the vertical alignment of the port with respect to its immediate parent(node/connector)
        /// </summary>
        [JsonPropertyName("verticalAlignment")]
        public VerticalAlignment VerticalAlignment
        {
            get { return verticalAlignment; }
            set
            {
                if (verticalAlignment != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(VerticalAlignment), value, verticalAlignment, this);
                    verticalAlignment = value;
                }
            }
        }
        /// <summary>
        /// Defines the space that the port has to be moved from its actual position
        /// </summary>
        [JsonPropertyName("margin")]
        public Margin Margin
        {
            get
            {
                if (margin != null && margin.Parent == null)
                    margin.SetParent(this, nameof(Margin));
                return margin;
            }
            set
            {
                if (margin != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Margin), value, margin, this);
                    margin = value;
                }
            }
        }
        /// <summary>
        /// Sets the width of the port
        /// </summary>
        [JsonPropertyName("width")]
        public double Width
        {
            get { return width; }
            set
            {
                if (width != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Width), value, width, this);
                    width = value;
                }
            }
        }
        /// <summary>
        ///  Sets the height of the port
        /// </summary>
        [JsonPropertyName("height")]
        public double Height
        {
            get { return height; }
            set
            {
                if (height != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Height), value, height, this);
                    height = value;
                }
            }
        }
        /// <summary>
        /// Defines the appearance of the port
        /// </summary>
        [JsonPropertyName("style")]
        public ShapeStyle Style
        {
            get
            {
                if (style != null && style.Parent == null)
                    style.SetParent(this, nameof(Style));
                return style;
            }
            set
            {
                if (style != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Style), value, style, this);
                    style = value;
                }
            }
        }
        /// <summary>
        /// Defines the type of the port shape
        /// </summary>
        [JsonPropertyName("shape")]
        public PortShapes Shape
        {
            get { return shape; }
            set
            {
                if (shape != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Shape), value, shape, this);
                    shape = value;
                }
            }
        }
        /// <summary>
        /// Defines the type of the port visibility
        /// </summary>
        [JsonPropertyName("visibility")]
        public PortVisibility Visibility
        {
            get { return visibility; }
            set
            {
                if (visibility != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Visibility), value, visibility, this);
                    visibility = value;
                }
            }
        }

        /// <summary>
        /// Defines the geometry of the port
        /// </summary>
        [JsonPropertyName("pathData")]
        public string PathData
        {
            get { return pathData; }
            set
            {
                if (pathData != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(PathData), value, pathData, this);
                    pathData = value;
                }
            }
        }

        /// <summary>
        /// Defines the constraints of port
        /// </summary>
        [JsonPropertyName("constraints")]
        public PortConstraints Constraints
        {
            get { return constraints; }
            set
            {
                if (constraints != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Constraints), value, constraints, this);
                    constraints = value;
                }
            }
        }
        /// <summary>
        /// Allows the user to save custom information/data about a port
        /// </summary>
        [JsonPropertyName("addInfo")]
        public object AddInfo
        {
            get { return addInfo; }
            set
            {
                if (addInfo != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(AddInfo), value, addInfo, this);
                    addInfo = value;
                }
            }
        }
        /// <summary>
        /// Defines the collection of the objects that are connected to a particular port
        /// </summary>
        [JsonPropertyName("outEdges")]
        public List<string> OutEdges
        {
            get { return outEdges; }
            set
            {
                if (outEdges != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(OutEdges), value, outEdges, this);
                    outEdges = value;
                }
            }
        }
        /// <summary>
        /// Defines the collection of the objects that are connected from a particular port
        /// </summary>
        [JsonPropertyName("inEdges")]
        public List<string> InEdges
        {
            get { return inEdges; }
            set
            {
                if (inEdges != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(InEdges), value, inEdges, this);
                    inEdges = value;
                }
            }
        }
        public override object Clone()
        {
            return new Port(this);
        }
    }

    /**
     * Defines the behavior of a port, that sticks to a point
     */
    public class PointPort : Port
    {
        [JsonIgnore]
        internal Point offset { get; set; } = new Point() { X = 0.5, Y = 0.5 };
        public PointPort(PointPort src) : base(src)
        {
            if (src.offset != null)
            {
                offset = src.offset.Clone() as Point;
            }
        }
        public PointPort() : base()
        {
        }
        /// <summary>
        /// Defines the position of the port with respect to the boundaries of nodes/connector
        /// </summary>
        [JsonPropertyName("offset")]
        public Point Offset
        {
            get
            {
                if (offset != null && offset.Parent == null)
                    offset.SetParent(this, nameof(Offset));
                return offset;
            }
            set
            {
                if (offset != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Offset), value, offset, this);
                    offset = value;
                }
            }
        }
        public override object Clone()
        {
            return new PointPort(this);
        }
    }
}
