﻿using Syncfusion.Blazor.Diagram.Internal;
using System.Collections.Generic;
using System.Text.Json.Serialization;
namespace Syncfusion.Blazor.Diagram
{
    /// <summary>
    /// Defines the behavior of shape
    /// </summary>
    public class Shape : DiagramObject
    {
        public Shape(Shape src) : base(src)
        {
            type = src.type;
        }
        public Shape() : base()
        {

        }
        private Shapes type { get; set; } = Shapes.Basic;

        /// <summary>
        /// Defines the type of node shape.
        /// </summary>
        [JsonPropertyName("type")]
        public Shapes Type
        {
            get { return type; }
            set
            {
                if (type != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Type), value, type, this);
                    type = value;
                }
            }
        }
        public override object Clone()
        {
            return new Shape(this);
        }
    }

    /// <summary>
    /// Defines the behavior of the basic shape
    /// </summary>
    public class BasicShape : Shape
    {
        private BasicShapes shape { get; set; } = BasicShapes.Rectangle;
        private double cornerRadius { get; set; }
        private Point[] points { get; set; }
        [JsonIgnore]
        internal string PolygonPath { get; set; }
        public BasicShape() : base()
        {

            Type = Shapes.Basic;
        }
        public BasicShape(BasicShape src) : base(src)
        {
            shape = src.shape;
            cornerRadius = src.cornerRadius;
            PolygonPath = src.PolygonPath;
            if (src.points != null)
            {
                points = src.points;
            }
        }

        /// <summary>
        /// Defines the type of the basic shape
        /// </summary>
        [JsonPropertyName("shape")]
        public BasicShapes Shape
        {
            get { return shape; }
            set
            {
                if (shape != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Shape), value, shape, this);
                    shape = value;
                }
            }
        }

        /// <summary>
        /// Sets the corner of the node
        /// </summary>
        [JsonPropertyName("cornerRadius")]
        public double CornerRadius
        {
            get { return cornerRadius; }
            set
            {
                if (cornerRadius != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(CornerRadius), value, cornerRadius, this);
                    cornerRadius = value;
                }
            }
        }

        /// <summary>
        /// Defines the collection of points to draw a polygon
        /// </summary>
        [JsonPropertyName("points")]
        public Point[] Points
        {
            get { return points; }
            set
            {
                if (points != value)
                {
                    points = value;
                }
            }
        }
        public override object Clone()
        {
            return new BasicShape(this);
        }

    }

    
}

