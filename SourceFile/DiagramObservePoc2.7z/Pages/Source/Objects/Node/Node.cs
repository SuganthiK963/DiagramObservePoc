﻿using Syncfusion.Blazor.Diagram.Internal;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{

    /// <summary>
    /// Defines the behavior of nodes
    /// </summary>
    public class Node : NodeBase
    {
        [JsonIgnore]
        internal bool IsDirtNode { get; set; }
        private HorizontalAlignment horizontalAlignment { get; set; } = HorizontalAlignment.Left;
        private VerticalAlignment verticalAlignment { get; set; } = VerticalAlignment.Top;
        [JsonIgnore]
        internal string ProcessId { get; set; } = "";
        private NodeConstraints constraints { get; set; } = NodeConstraints.Default;
        private Shape shape { get; set; } = new BasicShape();
        private double borderWidth { get; set; } = 0;
        private string borderColor { get; set; } = "none";
        private Shadow shadow { get; set; } = new Shadow();
        private string backgroundColor { get; set; } = "transparent";
        private ShapeStyle style { get; set; } = new ShapeStyle() { Fill = "white" };
        private double rotateAngle { get; set; }
        private double? maxHeight { get; set; } = null;
        private double? maxWidth { get; set; } = null;
        private double? minHeight { get; set; } = null;
        private double? minWidth { get; set; } = null;
        private double? height { get; set; } = null;
        private double? width { get; set; } = null;
        private Point pivot { get; set; } = new Point() { X = 0.5, Y = 0.5 };
        private double offsetY { get; set; }
        private double offsetX { get; set; }
        private bool isExpanded { get; set; } = true;
        private ObservableCollection<PointPort> ports { get; set; } = new ObservableCollection<PointPort>();
        private ObservableCollection<ShapeAnnotation> annotations { get; set; } = new ObservableCollection<ShapeAnnotation>();
        private object data { get; set; }
        [JsonIgnore]
        internal Size NativeSize { get; set; } = null;
        [JsonPropertyName("outEdges")]
        public List<string> OutEdges { get; internal set; } = new List<string>();
        [JsonPropertyName("inEdges")]
        public List<string> InEdges { get; internal set; } = new List<string>();

        public Node() : base()
        {
            
        }
        public Node(Node src) : base(src)
        {
            IsDirtNode = src.IsDirtNode;
            offsetX = src.offsetX;
            offsetY = src.offsetY;
            rotateAngle = src.rotateAngle;
            maxHeight = src.maxHeight;
            NativeSize = src.NativeSize;
            data = src.data;
            maxWidth = src.maxWidth;
            minHeight = src.minHeight;
            minWidth = src.minWidth;
            horizontalAlignment = src.horizontalAlignment;
            borderWidth = src.borderWidth;
            borderColor = src.borderColor;
            constraints = src.constraints;
            height = src.height;
            width = src.width;
            ProcessId = src.ProcessId;
            backgroundColor = src.backgroundColor;
            verticalAlignment = src.verticalAlignment;
            if (src.style != null)
            {
                style = src.style.Clone() as ShapeStyle;
                style.Parent = this;
            }
            if (src.pivot != null)
            {
                pivot = src.pivot.Clone() as Point;
                pivot.Parent = this;
            }
            if (src.shape != null)
            {
                shape = src.shape.Clone() as Shape;
                shape.Parent = this;
            }
            if (src.shadow != null)
            {
                shadow = src.shadow.Clone() as Shadow;
                shadow.Parent = this;
            }
            ports = src.ports;
            annotations = new ObservableCollection<ShapeAnnotation>();
            if (src.annotations.Count > 0)
            {
                foreach (ShapeAnnotation annotation in src.annotations)
                {
                    ShapeAnnotation anno = annotation.Clone() as ShapeAnnotation;
                    annotations.Add(anno);
                }
            }
            ports = new ObservableCollection<PointPort>();
            if (src.ports.Count > 0)
            {
                foreach (PointPort pointPort in src.ports)
                {
                    PointPort port = pointPort.Clone() as PointPort;
                    ports.Add(port);
                }
            }
            OutEdges = new List<string>();
            InEdges = new List<string>();
        }

        /// <summary>
        /// Sets the x-coordinate of the position of the node
        /// </summary>
        [JsonPropertyName("offsetX")]
        public double OffsetX
        {
            get { return offsetX; }
            set
            {
                if (offsetX != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(OffsetX), value, offsetX, this);
                    offsetX = value;
                }
            }
        }

        /// <summary>
        /// Sets the y-coordinate of the position of the node
        /// </summary>
        [JsonPropertyName("offsetY")]
        public double OffsetY
        {
            get { return offsetY; }
            set
            {
                if (offsetY != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(OffsetY), value, offsetY, this);
                    offsetY = value;
                }
            }
        }
        [JsonPropertyName("ports")]
        public ObservableCollection<PointPort> Ports
        {
            get
            {
                return ports;
            }
            set
            {
               ports = value;
            }
        }
        [JsonPropertyName("annotations")]
        public ObservableCollection<ShapeAnnotation> Annotations
        {
            get
            {
                return annotations;
            }
            set
            {                
               annotations = value;
            }
        }

        [JsonPropertyName("pivot")]
        public Point Pivot
        {
            get
            {
                if (pivot != null && pivot.Parent == null)
                    pivot.SetParent(this, nameof(Pivot));
                return pivot;
            }
            set
            {
                if (pivot != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Pivot), value, pivot, this);
                    pivot = value;
                }
            }
        }
        /// <summary>
        /// Sets the width of the node
        /// </summary>
        [JsonPropertyName("width")]
        public double? Width
        {
            get { return width; }
            set
            {
                if (width != value)
                {
                    if (Parent != null)
                    {
                        IsDirtNode = true;
                        Parent.UpdatePropertyChanged(nameof(Width), value, width, this);
                    }
                    width = value;
                }
            }
        }

        /// <summary>
        /// Sets the height of the node
        /// </summary>
        [JsonPropertyName("height")]
        public double? Height
        {
            get { return height; }
            set
            {
                if (height != value)
                {
                    if (Parent != null)
                    {
                        IsDirtNode = true;
                        Parent.UpdatePropertyChanged(nameof(Height), value, height, this);
                    }
                    height = value;
                }
            }
        }

        /// <summary>
        /// Sets the minimum width of the node
        /// </summary>
        [JsonPropertyName("minWidth")]
        public double? MinWidth
        {
            get { return minWidth; }
            set
            {
                if (minWidth != value)
                {
                    if (Parent != null)
                    {
                        IsDirtNode = true;
                        Parent.UpdatePropertyChanged(nameof(MinWidth), value, minWidth, this);
                    }
                    minWidth = value;
                }
            }
        }

        /// <summary>
        /// Sets the minimum height of the node
        /// </summary>
        [JsonPropertyName("minHeight")]
        public double? MinHeight
        {
            get { return minHeight; }
            set
            {
                if (minHeight != value)
                {
                    if (Parent != null)
                    {
                        IsDirtNode = true;
                        Parent.UpdatePropertyChanged(nameof(MinHeight), value, minHeight, this);
                    }
                    minHeight = value;
                }
            }
        }

        /// <summary>
        /// Sets the maximum width of the node
        /// </summary>
        [JsonPropertyName("maxWidth")]
        public double? MaxWidth
        {
            get { return maxWidth; }
            set
            {
                if (maxWidth != value)
                {
                    if (Parent != null)
                    {
                        IsDirtNode = true;
                        Parent.UpdatePropertyChanged(nameof(MaxWidth), value, maxWidth, this);
                    }
                    maxWidth = value;
                }
            }
        }

        /// <summary>
        /// Sets the maximum height of the node
        /// </summary>
        [JsonPropertyName("maxHeight")]
        public double? MaxHeight
        {
            get { return maxHeight; }
            set
            {
                if (maxHeight != value)
                {
                    if (Parent != null)
                    {
                        IsDirtNode = true;
                        Parent.UpdatePropertyChanged(nameof(MaxHeight), value, maxHeight, this);
                    }
                    maxHeight = value;
                }
            }
        }

        /// <summary>
        /// Sets the rotate angle of the node
        /// </summary>
        [JsonPropertyName("rotateAngle")]
        public double RotateAngle
        {
            get { return rotateAngle; }
            set
            {
                if (rotateAngle != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(RotateAngle), value, rotateAngle, this);
                    rotateAngle = value;
                }
            }
        }

        /// <summary>
        /// Sets the shape style of the node
        /// </summary>
        [JsonPropertyName("style")]
        public ShapeStyle Style
        {
            get
            {
                if (style != null && style.Parent == null)
                    style.SetParent(this, nameof(Style));
                return style;
            }
            set
            {
                if (style != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Style), value, style, this);
                    style = value;
                }
            }
        }

        /// <summary>
        /// Sets the shadow of the shape
        /// </summary>
        [JsonPropertyName("shadow")]
        public Shadow Shadow
        {
            get
            {
                if (shadow != null && shadow.Parent == null)
                    shadow.SetParent(this, nameof(Shadow));
                return shadow;
            }
            set
            {
                if (shadow != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Shadow), value, shadow, this);
                    shadow = value;
                }
            }
        }

        /// <summary>
        /// Sets the background color of the shape
        /// </summary>
        [JsonPropertyName("backgroundColor")]
        public string BackgroundColor
        {
            get { return backgroundColor; }
            set
            {
                if (backgroundColor != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(BackgroundColor), value, backgroundColor, this);
                    backgroundColor = value;
                }
            }
        }

        /// <summary>
        /// Sets the border color of the node
        /// </summary>
        [JsonPropertyName("borderColor")]
        public string BorderColor
        {
            get { return borderColor; }
            set
            {
                if (borderColor != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(BorderColor), value, borderColor, this);
                    borderColor = value;
                }
            }
        }

        /// <summary>
        /// Sets the border width of the node
        /// </summary>
        [JsonPropertyName("borderWidth")]
        public double BorderWidth
        {
            get { return borderWidth; }
            set
            {
                if (borderWidth != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(BorderWidth), value, borderWidth, this);
                    borderWidth = value;
                }
            }
        }

        /// <summary>
        /// Defines the shape of a node
        /// </summary>
        [JsonPropertyName("data")]
        public object Data
        {
            get { return data; }
            set
            {
                if (data != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Data), value, data, this);
                    data = value;
                }
            }
        }
        [JsonPropertyName("shape")]
        public Shape Shape
        {
            get
            {
                if (shape != null && shape.Parent == null)
                    shape.SetParent(this, nameof(Shape));
                return shape;
            }
            set
            {
                if (shape != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Shape), value, shape, this);
                    shape = value;
                }
            }
        }

        /// <summary>
        /// Enables/Disables certain features of nodes
        /// </summary>
        [JsonPropertyName("constraints")]
        public NodeConstraints Constraints
        {
            get
            {
                return constraints;
            }
            set
            {
                if (constraints != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(Constraints), value, constraints, this);
                    constraints = value;
                }
            }
        }

        /// <summary>
        /// Sets the horizontalAlignment of the node
        /// </summary>
        [JsonPropertyName("horizontalAlignment")]
        public HorizontalAlignment HorizontalAlignment
        {
            get { return horizontalAlignment; }
            set
            {
                if (horizontalAlignment != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(HorizontalAlignment), value, horizontalAlignment, this);
                    horizontalAlignment = value;
                }
            }
        }

        /// <summary>
        /// Sets the verticalAlignment of the node
        /// </summary>
        [JsonPropertyName("verticalAlignment")]
        public VerticalAlignment VerticalAlignment
        {
            get { return verticalAlignment; }
            set
            {
                if (verticalAlignment != value)
                {
                    if (Parent != null)
                        Parent.UpdatePropertyChanged(nameof(VerticalAlignment), value, verticalAlignment, this);
                    verticalAlignment = value;
                }
            }
        }

        public override object Clone()
        {
            return new Node(this);
        }
    }

}
