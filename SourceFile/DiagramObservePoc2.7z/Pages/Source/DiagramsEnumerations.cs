using System;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace Syncfusion.Blazor.Diagram
{

    /// <summary>
    ///Enables/Disables certain features of diagram.
    /// </summary>
    public enum DiagramConstraints
    {
        /// <summary>
        /// Disable DiagramConstraints constraints.
        /// </summary>
        None = 0,
        /// <summary>
        /// Enables/Disable Bridging support for connector.
        /// </summary>
        Bridging = 1 << 1,
        /// <summary>
        /// Enables/Disable the Undo/Redo support.
        /// </summary>
        UndoRedo = 1 << 2,
        /// <summary>
        /// Enables/Disable UserInteraction support for the diagram.
        /// </summary>
        UserInteraction = 1 << 3,
        /// <summary>
        /// Enables/Disable ApiUpdate support for the diagram.
        /// </summary>
        ApiUpdate = 1 << 4,
        /// <summary>
        /// Enables/Disable PageEditable support for the diagram.
        /// </summary>
        PageEditable = 1 << 3 | 1 << 4,
        /// <summary>
        /// Enables/Disable Zoom support for the diagram.
        /// </summary>
        Zoom = 1 << 5,
        /// <summary>
        /// Enables/Disable PanX support for the diagram.
        /// </summary>
        PanX = 1 << 6,
        /// <summary>
        /// Enables/Disable PanY support for the diagram.
        /// </summary>
        PanY = 1 << 7,
        /// <summary>
        /// Enables/Disable Pan support the diagram.
        /// </summary>
        Pan = 1 << 6 | 1 << 7,
        /// <summary>
        /// Enables/Disable Virtualization support the diagram.
        /// </summary>
        Virtualization = 1 << 8,
        /// <summary>
        /// Enables/Disables zooming the text box while editing the text.
        /// </summary>
        ZoomTextEdit = 1 << 9,
        /// <summary>
        /// Enables/Disable all constraints.
        /// </summary>
        Default = 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6 | 1 << 7
    }

    /// <summary>
    /// Specifies how the diagram elements have to be flipped.
    /// </summary>
    internal enum FlipDirection
    {
        /// <summary>
        /// Flip the diagram shape horizontally.
        /// </summary>
        [EnumMember(Value = "Horizontal")]
        Horizontal,
        /// <summary>
        /// Flip the diagram shape vertically.
        /// </summary>
        [EnumMember(Value = "Vertical")]
        Vertical,
        /// <summary>
        /// Flip the diagram shape to both horizontally and vertically. 
        /// </summary>
        [EnumMember(Value = "Both")]
        Both,
        /// <summary>
        /// No flip will be applied and this is the default value. 
        /// </summary>
        [EnumMember(Value = "None")]
        None,
    }

    /// <summary>
    /// Defines how the diagram elements must be aligned based on its immediate parent.
    /// </summary>
    public enum HorizontalAlignment
    {
        /// <summary>
        /// Stretch the diagram element horizontally to its immediate parent�s. 
        /// </summary>
        [EnumMember(Value = "Stretch")]
        Stretch,
        /// <summary>
        /// Align the diagram element horizontally to its immediate parent's left side.
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Align the diagram element horizontally to its immediate parent's right side.
        /// </summary>
        [EnumMember(Value = "Right")]
        Right,
        /// <summary>
        /// Align the diagram element horizontally to the center of its immediate parent.
        /// </summary>
        [EnumMember(Value = "Center")]
        Center,
        /// <summary>
        /// Aligns the diagram element based on its immediate parent�s horizontal alignment property.
        /// </summary>
        [EnumMember(Value = "Auto")]
        Auto,
    }

    /// <summary>
    /// Defines how the fixedUserHandle have to be aligned with respect to its immediate parent
    /// </summary>
    public enum FixedUserHandleAlignment
    {
        /// <summary>
        /// Aligns the fixedUserHandle at the center of a connector segment. 
        /// </summary>
        [EnumMember(Value = "Center")]
        Center,
        /// <summary>
        /// Aligns the fixedUserHandle before a connector segment.
        /// </summary>
        [EnumMember(Value = "Before")]
        Before,
        /// <summary>
        /// Aligns the fixedUserHandle after a connector segment.
        /// </summary>
        [EnumMember(Value = "After")]
        After
    }
    /// <summary>
    /// Defines how the grid line type
    /// </summary>
    public enum GridType
    {
        /// <summary>
        /// Renders grid patterns as Lines. 
        /// </summary>
        [EnumMember(Value = "Lines")]
        Lines,
        /// <summary>
        /// Renders grid patterns as Dots.
        /// </summary>
        [EnumMember(Value = "Dots")]
        Dots,
    }

    /// <summary>
    /// Defines how the diagram elements must be aligned based on its immediate parent.
    /// </summary>
    public enum VerticalAlignment
    {
        /// <summary>
        /// Stretch the diagram element vertically to its immediate parent�s.
        /// </summary>
        [EnumMember(Value = "Stretch")]
        Stretch,
        /// <summary>
        /// Align the diagram element vertically to its immediate parent's top side.
        /// </summary>
        [EnumMember(Value = "Top")]
        Top,
        /// <summary>
        /// Align the diagram element vertically to its immediate parent's bottom side.
        /// </summary>
        [EnumMember(Value = "Bottom")]
        Bottom,
        /// <summary>
        /// Align the diagram element vertically to the center of its immediate parent.
        /// </summary>
        [EnumMember(Value = "Center")]
        Center,
        /// <summary>
        /// Aligns the diagram element based on its immediate parent�s Vertical alignment property.
        /// </summary>
        [EnumMember(Value = "Auto")]
        Auto,
    }

    /// <summary>
    /// The TextDecoration property defines the decoration for a text in the text block.
    /// </summary>
    [JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum TextDecoration
    {
        /// <summary>
        /// The Overline property draws a horizontal line above the text.
        /// </summary>
        [EnumMember(Value = "Overline")]
        Overline,
        /// <summary>
        /// This property draws a horizontal line under the text in the text block.
        /// </summary>
        [EnumMember(Value = "Underline")]
        Underline,
        /// <summary>
        /// LineThrough property draws a horizontal line in the center of the text of a node or a connector.
        /// </summary>
        [EnumMember(Value = "LineThrough")]
        LineThrough,
        /// <summary>
        /// The None property represents the default text.
        /// </summary>
        [EnumMember(Value = "None")]
        None,
    }

    /// <summary>
    /// The TextAlign property allows the user to define the alignment of the text inside the text block. 
    /// </summary>
    [JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum TextAlign
    {
        /// <summary>
        /// Sets the alignment of text in the text block to the left.
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Sets the alignment of text in the text block to the right.
        /// </summary>
        [EnumMember(Value = "Right")]
        Right,
        /// <summary>
        /// Sets the alignment of text in the text block to the center.
        /// </summary>
        [EnumMember(Value = "Center")]
        Center,
        /// <summary>
        /// Sets the alignment of text in respective to left and right margins.
        /// </summary>
        [EnumMember(Value = "Justify")]
        Justify,
    }

    /// <summary>
    /// The overflow property allows the user to clip the text content or to add scrollbars when the content of the text element is too large to fit in the specified diagram area.
    /// </summary>
    [JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum TextOverflow
    {
        /// <summary>
        /// Wraps the text to the next line, when it exceeds its bounds.
        /// </summary>
        [EnumMember(Value = "Wrap")]
        Wrap,
        /// <summary>
        /// Ellipsis hides the text if the text size exceeds the boundary.
        /// </summary>
        [EnumMember(Value = "Ellipsis")]
        Ellipsis,
        /// <summary>
        /// The text is restricted to the node/connector boundary and the text will not be overflown.
        /// </summary>
        [EnumMember(Value = "Clip")]
        Clip,
    }

    /// <summary>
    /// TextWrap property is used to control the overflow of text in the node boundaries. The wrapping property defines how the text should be wrapped.
    /// </summary>
    [JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum TextWrap
    {
        /// <summary>
        /// Text-wrapping occurs when the text overflows beyond the available node width. However, the text may overflow beyond the node width in the case of a very long word.
        /// </summary>
        [EnumMember(Value = "WrapWithOverflow")]
        WrapWithOverflow,
        /// <summary>
        /// The text will be wrapped inside the boundary.
        /// </summary>
        [EnumMember(Value = "Wrap")]
        Wrap,
        /// <summary>
        /// The text will not be wrapped. If lengthy text exists, the boundary will not be a limitation.
        /// </summary>
        [EnumMember(Value = "NoWrap")]
        NoWrap,
    }

    /// <summary>
    /// Specifies how the white space and new line characters should be set.
    /// </summary>
    [JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum WhiteSpace
    {
        /// <summary>
        /// Preserves (Includes) all empty spaces and empty lines
        /// </summary>
        [EnumMember(Value = "PreserveAll")]
        PreserveAll,
        /// <summary>
        /// Collapses (Excludes) all consequent empty spaces and empty lines
        /// </summary>
        [EnumMember(Value = "CollapseSpace")]
        CollapseSpace,
        /// <summary>
        /// Collapses (Excludes) the consequent spaces into one
        /// </summary>
        [EnumMember(Value = "CollapseAll")]
        CollapseAll,
    }

    /// <summary>
    /// Specifies the type of transition between two or more colors.
    /// </summary>
    public enum GradientType
    {
        /// <summary>
        /// No gradient will be applied by default. 
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of gradient as Linear.
        /// </summary>
        [EnumMember(Value = "Linear")]
        Linear,
        /// <summary>
        /// Sets the type of gradient as Radial.
        /// </summary>
        [EnumMember(Value = "Radial")]
        Radial,
    }
    /// <summary>
    /// Specifies the relative mode.
    /// </summary>
    public enum RelativeMode
    {
        /// <summary>
        /// Point - Diagram elements will be aligned with respect to a point
        /// </summary>
        Point,
        /// <summary>
        /// Object - Diagram elements will be aligned with respect to its immediate parent
        /// </summary>
        Object
    }
    /// <summary>
    /// Specifies the type of Transform.
    /// </summary>
    public enum Transform
    {
        /// <summary>
        /// Self - Sets the transform type as Self
        /// </summary>
        Self,
        /// <summary>
        /// Parent - Sets the transform type as Parent
        /// </summary>
        Parent
    }
    /// <summary>
    /// Specifies the element action.
    /// </summary>
    public enum ElementAction
    {
        /// <summary>
        /// Disables all element actions are none.
        /// </summary>
        None = 0,
        /// <summary>
        /// Enable the element action is Port.
        /// </summary>
        ElementIsPort = 1 << 1,
        /// <summary>
        /// Enable the element action as Group.
        /// </summary>
        ElementIsGroup = 1 << 2,
    }
    /// <summary>
    /// Specifies the type of unit mode.
    /// </summary>
    public enum UnitMode
    {
        /// <summary>
        /// Absolute - Sets the unit mode type as Absolute
        /// </summary>
        Absolute,
        /// <summary>
        /// Fraction - Sets the unit mode type as Fraction
        /// </summary>
        Fraction
    }


    /// <summary>
    /// Specifies the shape of the ports.
    /// </summary>
    public enum PortShapes
    {
        /// <summary>
        /// Sets the port shape as X.
        /// </summary>
        [EnumMember(Value = "X")]
        X,
        /// <summary>
        /// Sets the port shape as Circle.
        /// </summary>
        [EnumMember(Value = "Circle")]
        Circle,
        /// <summary>
        /// Sets the port shape as Square.
        /// </summary>
        [EnumMember(Value = "Square")]
        Square,
        /// <summary>
        /// Sets the port shape as Custom.
        /// </summary>
        [EnumMember(Value = "Custom")]
        Custom,
    }

    /// <summary>
    /// Constraints to control the visibility property of the port.
    /// </summary>
    /// </example>
    [Flags]
    public enum PortVisibility
    {
        /// <summary>
        /// Shows the port when a connector endpoint is dragged over a node.
        /// </summary>
        Connect = 1 << 3,
        /// <summary>
        /// Always hides the port.
        /// </summary>
        Hidden = 1 << 1,
        /// <summary>
        /// Shows the port when the mouse hovers over a node. 
        /// </summary>
        Hover = 1 << 2,
        /// <summary>
        /// Always shows the port.
        /// </summary>
        Visible = 1 << 0
    }
    /// <summary>
    ///Defines the specific mode, with respect to which the objects to be aligned. 
    /// </summary>
    public enum AlignmentMode
    {
        /// <summary>
        ///Aligns the objects based on the first object in the selected list. 
        /// </summary>
        Object,
        /// <summary>
        ///Aligns the objects based on the selection boundary. 
        /// </summary>
        Selector
    }
    /// <summary>
    ///Defines the specific direction, with respect to which the objects to be aligned.
    /// </summary>
    public enum AlignmentOptions
    {
        /// <summary>
        ///Aligns all the selected objects at the left of the selection boundary.
        /// </summary>
        Left,
        /// <summary>
        ///	Aligns all the selected objects at the right of the selection boundary
        /// </summary>
        Right,
        /// <summary>
        /// 	Aligns all the selected objects at the top of the selection boundary.
        /// </summary>
        Top,
        /// <summary>
        ///	Aligns all the selected objects at the bottom of the selection boundary
        /// </summary>
        Bottom,
        /// <summary>
        ///Aligns all the selected objects at the center of the selection boundary
        /// </summary>
        Center,
        /// <summary>
        /// Aligns all the selected objects at the middle of the selection boundary.
        /// </summary>
        Middle,
    }
    /// <summary>
    /// Specifies the Distribute otions
    /// </summary>
    public enum DistributeOptions
    {
        /// <summary>
        /// Distributes the objects based on the distance between the right and left sides of the adjacent objects.
        /// </summary>
        RightToLeft,
        /// <summary>
        ///Distributes the objects based on the distance between the center of the adjacent objects.
        /// </summary>
        Center,
        /// <summary>
        ///Distributes the objects based on the distance between the left sides of the adjacent objects.
        /// </summary>
        Left,
        /// <summary>
        ///Distributes the objects based on the distance between the right sides of the adjacent objects.
        /// </summary>
        Right,
        /// <summary>
        /// Distributes the objects based on the distance between the bottom sides of the adjacent objects.
        /// </summary>
        Bottom,
        /// <summary>
        ///Distributes the objects based on the distance between the top sides of the adjacent objects.
        /// </summary>
        Top,
        /// <summary>
        ///Distributes the objects based on the distance between the bottom and top sides of the adjacent objects.
        /// </summary>
        BottomToTop,
        /// <summary>
        ///  Distributes the objects based on the distance between the vertical center of the adjacent objects.
        /// </summary>
        Middle,
    }
    /// <summary>
    /// Specifies the sizing types
    /// </summary>
    public enum SizingTypes
    {
        /// <summary>
        ///Scales the selected objects both vertically and horizontally.
        /// </summary>
        Size,
        /// <summary>
        ///Scales the height of the selected objects.
        /// </summary>
        Height,
        /// <summary>
        /// Scales the width of the selected objects.
        /// </summary>
        Width,
    }
    /// <summary>
    /// The behavior and features of the ports can be enabled or disabled using the PortConstraints.
    /// </summary>
    [Flags]
    public enum PortConstraints
    {
        /// <summary>
        /// Disables all the Port functionalities.
        /// </summary>
        None = 0,
        /// <summary>
        /// Enables to create the connection when mouse hover on the port.
        /// </summary>
        Draw = 1 << 1,
        /// <summary>
        /// Enables or disables to connect only the target end of connector.
        /// </summary>
        InConnect = 1 << 2,
        /// <summary>
        /// Enables or disables to connect only the source end of connector.
        /// </summary>
        OutConnect = 1 << 3,
        /// <summary>
        /// Enables all constraints for a port.
        /// </summary>
        Default = 1 << 2 | 1 << 3,
    }
    /// Specifies the type of a node.
    /// </summary>
    public enum Shapes
    {
        /// <summary>
        /// Sets the node as Basic.
        /// </summary>
        [EnumMember(Value = "Basic")]
        Basic,
        /// <summary>
        /// Sets the node as Path.
        /// </summary>
        [EnumMember(Value = "Path")]
        Path,
        /// <summary>
        /// Sets the node as Text.
        /// </summary>
        [EnumMember(Value = "Text")]
        Text,
        /// <summary>
        /// Sets the node as Image.
        /// </summary>
        [EnumMember(Value = "Image")]
        Image,
        /// <summary>
        /// Sets the node as Flow.
        /// </summary>
        [EnumMember(Value = "Flow")]
        Flow,
        /// <summary>
        /// Sets the node as Bpmn.
        /// </summary>
        [EnumMember(Value = "Bpmn")]
        Bpmn,
        /// <summary>
        /// Sets the node as Native.
        /// </summary>
        [EnumMember(Value = "Native")]
        Native,
        /// <summary>
        /// Sets the node as HTML.
        /// </summary>
        [EnumMember(Value = "HTML")]
        HTML,
    }

    /// <summary>
    /// Specifies the common shapes that are used to represent information visually.
    /// </summary>
    public enum BasicShapes
    {
        /// <summary>
        /// Sets the type of the basic shape as Rectangle.
        /// </summary>
        [EnumMember(Value = "Rectangle")]
        Rectangle,
        /// <summary>
        /// Sets the type of the basic shape as Ellipse.
        /// </summary>
        [EnumMember(Value = "Ellipse")]
        Ellipse,
        /// <summary>
        /// Sets the type of the basic shape as Hexagon.
        /// </summary>
        [EnumMember(Value = "Hexagon")]
        Hexagon,
        /// <summary>
        /// Sets the type of the basic shape as Parallelogram.
        /// </summary>
        [EnumMember(Value = "Parallelogram")]
        Parallelogram,
        /// <summary>
        /// Sets the type of the basic shape as Triangle.
        /// </summary>
        [EnumMember(Value = "Triangle")]
        Triangle,
        /// <summary>
        /// Sets the type of the basic shape as Plus.
        /// </summary>
        [EnumMember(Value = "Plus")]
        Plus,
        /// <summary>
        /// Sets the type of the basic shape as Star.
        /// </summary>
        [EnumMember(Value = "Star")]
        Star,
        /// <summary>
        /// Sets the type of the basic shape as Pentagon.
        /// </summary>
        [EnumMember(Value = "Pentagon")]
        Pentagon,
        /// <summary>
        /// Sets the type of the basic shape as Heptagon.
        /// </summary>
        [EnumMember(Value = "Heptagon")]
        Heptagon,
        /// <summary>
        /// Sets the type of the basic shape as Octagon.
        /// </summary>
        [EnumMember(Value = "Octagon")]
        Octagon,
        /// <summary>
        /// Sets the type of the basic shape as Trapezoid.
        /// </summary>
        [EnumMember(Value = "Trapezoid")]
        Trapezoid,
        /// <summary>
        /// Sets the type of the basic shape as Decagon.
        /// </summary>
        [EnumMember(Value = "Decagon")]
        Decagon,
        /// <summary>
        /// Sets the type of the basic shape as the Right Triangle.
        /// </summary>
        [EnumMember(Value = "RightTriangle")]
        RightTriangle,
        /// <summary>
        /// Sets the type of the basic shape as Cylinder.
        /// </summary>
        [EnumMember(Value = "Cylinder")]
        Cylinder,
        /// <summary>
        /// Sets the type of the basic shape as Diamond.
        /// </summary>
        [EnumMember(Value = "Diamond")]
        Diamond,
        /// <summary>
        /// Sets the type of the basic shape as Polygon.
        /// </summary>
        [EnumMember(Value = "Polygon")]
        Polygon,
    }

    /// <summary>
    /// Specifies the type of process flow used for analyzing designing and managing for documentation process.
    /// </summary>
    public enum FlowShapes
    {
        /// <summary>
        /// Sets the flow shape type as Terminator.
        /// </summary>
        [EnumMember(Value = "Terminator")]
        Terminator,
        /// <summary>
        /// Sets the flow shape type as Process.
        /// </summary>
        [EnumMember(Value = "Process")]
        Process,
        /// <summary>
        /// Sets the flow shape type as Decision.
        /// </summary>
        [EnumMember(Value = "Decision")]
        Decision,
        /// <summary>
        /// Sets the flow shape type as Document.
        /// </summary>
        [EnumMember(Value = "Document")]
        Document,
        /// <summary>
        /// Sets the flow shape type as PreDefinedProcess.
        /// </summary>
        [EnumMember(Value = "PreDefinedProcess")]
        PreDefinedProcess,
        /// <summary>
        /// Sets the flow shape type as PaperTap.
        /// </summary>
        [EnumMember(Value = "PaperTap")]
        PaperTap,
        /// <summary>
        /// Sets the flow shape type as DirectData.
        /// </summary>
        [EnumMember(Value = "DirectData")]
        DirectData,
        /// <summary>
        /// Sets the flow shape type as SequentialData.
        /// </summary>
        [EnumMember(Value = "SequentialData")]
        SequentialData,
        /// <summary>
        /// Sets the flow shape type as Sort.
        /// </summary>
        [EnumMember(Value = "Sort")]
        Sort,
        /// <summary>
        /// Sets the flow shape type as MultiDocument.
        /// </summary>
        [EnumMember(Value = "MultiDocument")]
        MultiDocument,
        /// <summary>
        /// Sets the flow shape type as Collate.
        /// </summary>
        [EnumMember(Value = "Collate")]
        Collate,
        /// <summary>
        /// Sets the flow shape type as SummingJunction.
        /// </summary>
        [EnumMember(Value = "SummingJunction")]
        SummingJunction,
        /// <summary>
        /// Sets the flow shape type as Or.
        /// </summary>
        [EnumMember(Value = "Or")]
        Or,
        /// <summary>
        /// Sets the flow shape type as internal storage.
        /// </summary>
        [EnumMember(Value = "InternalStorage")]
        InternalStorage,
        /// <summary>
        /// Sets the flow shape type as Extract.
        /// </summary>
        [EnumMember(Value = "Extract")]
        Extract,
        /// <summary>
        /// Sets the flow shape type as ManualOperation.
        /// </summary>
        [EnumMember(Value = "ManualOperation")]
        ManualOperation,
        /// <summary>
        /// Sets the flow shape type as Merge.
        /// </summary>
        [EnumMember(Value = "Merge")]
        Merge,
        /// <summary>
        /// Sets the flow shape type as OffPageReference.
        /// </summary>
        [EnumMember(Value = "OffPageReference")]
        OffPageReference,
        /// <summary>
        /// Sets the flow shape type as SequentialAccessStorage.
        /// </summary>
        [EnumMember(Value = "SequentialAccessStorage")]
        SequentialAccessStorage,
        /// <summary>
        /// Sets the flow shape type as Annotation.
        /// </summary>
        [EnumMember(Value = "Annotation")]
        Annotation,
        /// <summary>
        /// Sets the flow shape type as Annotation2.
        /// </summary>
        [EnumMember(Value = "Annotation2")]
        Annotation2,
        /// <summary>
        /// Sets the flow shape type as Data.
        /// </summary>
        [EnumMember(Value = "Data")]
        Data,
        /// <summary>
        /// Sets the flow shape type as Card.
        /// </summary>
        [EnumMember(Value = "Card")]
        Card,
        /// <summary>
        /// Sets the flow shape type as Delay.
        /// </summary>
        [EnumMember(Value = "Delay")]
        Delay,
        /// <summary>
        /// Sets the flow shape type as Preparation.
        /// </summary>
        [EnumMember(Value = "Preparation")]
        Preparation,
        /// <summary>
        /// Sets the flow shape type as Display.
        /// </summary>
        [EnumMember(Value = "Display")]
        Display,
        /// <summary>
        /// Sets the flow shape type as ManualInput.
        /// </summary>
        [EnumMember(Value = "ManualInput")]
        ManualInput,
        /// <summary>
        /// Sets the flow shape type as LoopLimit.
        /// </summary>
        [EnumMember(Value = "LoopLimit")]
        LoopLimit,
        /// <summary>
        /// Sets the flow shape type as stored data.
        /// </summary>
        [EnumMember(Value = "StoredData")]
        StoredData,
    }

    /// <summary>
    /// Specifies the node constraints allow the users to enable or disable certain behaviors and features of the diagram nodes.
    /// </summary>
    [Flags]
    public enum NodeConstraints
    {
        /// <summary>
        /// Disable all node Constraints.
        /// </summary>
        None = 0,
        /// <summary>
        /// Enables or disables the selection of a node in the diagram.
        /// </summary>
        Select = 1 << 1,
        /// <summary>
        /// Enables or disables the dragging functionality of a node.
        /// </summary>
        Drag = 1 << 2,
        /// <summary>
        /// Enables or disables node rotation. It is done with the help of a curvy arrow.
        /// </summary>
        Rotate = 1 << 3,
        /// <summary>
        /// Enables or disables to display the nodes shadow.
        /// </summary>
        Shadow = 1 << 4,
        /// <summary>
        /// Enables or disables the mouse pointers events when clicking with a mouse.
        /// </summary>
        PointerEvents = 1 << 5,
        /// <summary>
        /// Enables or disables node deletion.
        /// </summary>
        Delete = 1 << 6,
        /// <summary>
        /// Enables node to allow only in coming connections.
        /// </summary>
        InConnect = 1 << 7,
        /// <summary>
        /// Enables node to allow only out coming connections.
        /// </summary>
        OutConnect = 1 << 8,
        /// <summary>
        /// AllowDrop allows dropping a node.
        /// </summary>
        AllowDrop = 1 << 9,
        /// <summary>
        /// It enables or disables the resizing of the node in the NorthEast direction.
        /// </summary>
        ResizeNorthEast = 1 << 10,
        /// <summary>
        /// It enables or disables the resizing of the node in the East direction.
        /// </summary>
        ResizeEast = 1 << 11,
        /// <summary>
        /// It enables or disables the resizing of the node in the SouthEast direction.
        /// </summary>
        ResizeSouthEast = 1 << 12,
        /// <summary>
        /// It enables or disables the resizing of the node in the South direction.
        /// </summary>
        ResizeSouth = 1 << 13,
        /// <summary>
        /// It enables or disables the resizing of the node in the SouthWest direction.
        /// </summary>
        ResizeSouthWest = 1 << 14,
        /// <summary>
        /// It enables or disables the resizing of the node in the West direction.
        /// </summary>
        ResizeWest = 1 << 15,
        /// <summary>
        /// It enables or disables the resizing of the node in the NorthWest direction.
        /// </summary>
        ResizeNorthWest = 1 << 16,
        /// <summary>
        /// It enables or disables the resizing of the node in the North direction.
        /// </summary>
        ResizeNorth = 1 << 17,
        /// <summary>
        /// Enables the Aspect ratio of the node.
        /// </summary>
        AspectRatio = 1 << 18,
        /// <summary>
        /// Enables the ReadOnly mode(Write operations cannot be done) for the annotation in the node.
        /// </summary>
        ReadOnly = 1 << 19,
        /// <summary>
        /// Enables to hide all resize thumbs for the node.
        /// </summary>
        HideThumbs = 1 << 20,
        /// <summary>
        /// Enables or Disables the expansion or compression of a node.
        /// </summary>
        Resize = 1 << 10 | 1 << 11 | 1 << 12 | 1 << 13 | 1 << 14 | 1 << 15 | 1 << 16 | 1 << 17,
        /// <summary>
        /// Enables all the constraints for a node
        /// </summary>
        Default = 1 << 1 | 1 << 2 | 1 << 3 | 1 << 6 | 1 << 7 | 1 << 8 | 1 << 5 | 1 << 10 | 1 << 11 |
    1 << 12 | 1 << 13 | 1 << 14 | 1 << 15 | 1 << 16 | 1 << 17,
        /// <summary>
        /// It allows the node to inherit the interaction option from the parent object.
        /// </summary>
        Inherit = 1 << 1 | 1 << 2 | 1 << 3 | 1 << 6,
    }

    /// <summary>
    /// The connector constraints allow the users to enable or disable certain behaviors and features of the connectors.
    /// </summary>
    [Flags]
    public enum ConnectorConstraints
    {
        /// <summary>
        /// Disable all connector Constraints.
        /// </summary>
        None = 0,
        /// <summary>
        /// Enables or Disables the selection of a  connector.
        /// </summary>
        Select = 1 << 1,
        /// <summary>
        /// Enables or Disables the deletion of a connector.
        /// </summary>
        Delete = 1 << 2,
        /// <summary>
        /// Enables or Disables connector to be Dragged.
        /// </summary>
        Drag = 1 << 3,
        /// <summary>
        /// Enables the connector's source end to be dragged.
        /// </summary>
        DragSourceEnd = 1 << 4,
        /// <summary>
        /// Enables connectors target end to be dragged.
        /// </summary>
        DragTargetEnd = 1 << 5,
        /// <summary>
        /// Enables the control point and endpoint of every segment in a connector for editing.
        /// </summary>
        DragSegmentThumb = 1 << 6,
        /// <summary>
        /// Enables or disables Interaction for the connector.
        /// </summary>
        Interaction = 1 << 1 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6,
        /// <summary>
        /// Enables to trigger drop event when any object is dragged or dropped to the connector.
        /// </summary>
        AllowDrop = 1 << 7,
        /// <summary>
        /// Enables bridging to the connector.
        /// </summary>
        Bridging = 1 << 8,
        /// <summary>
        /// Enables to inherit bridging option from the parent object.
        /// </summary>
        InheritBridging = 1 << 9,
        /// <summary>
        /// Enables to set the pointer-events.
        /// </summary>
        PointerEvents = 1 << 10,
        /// <summary>
        /// Enables or disables read-only for the connector.
        /// </summary>
        ReadOnly = 1 << 11,
        /// <summary>
        /// Enables to connect nearest node.
        /// </summary>
        ConnectToNearByNode = 1 << 12,
        /// <summary>
        /// Enables to connect nearest port.
        /// </summary>
        ConnectToNearByPort = 1 << 13,
        /// <summary>
        /// Enables to connect nearest elements.
        /// </summary>
        ConnectToNearByElement = 1 << 12 | 1 << 13,
        /// <summary>
        /// Enables all constraints for the connector.
        /// </summary>
        Default = 1 << 1 | 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 9 | 1 << 10 | 1 << 12 | 1 << 13,
    }


    /// <summary>
    /// Specifies the segment type of the connector.
    /// </summary>
    public enum Segments
    {
        /// <summary>
        /// Sets the segment type as Straight.
        /// </summary>
        [EnumMember(Value = "Straight")]
        Straight,
        /// <summary>
        /// Sets the segment type as Orthogonal.
        /// </summary>
        [EnumMember(Value = "Orthogonal")]
        Orthogonal,
        /// <summary>
        /// Sets the segment type as Polyline.
        /// </summary>
        [EnumMember(Value = "Polyline")]
        Polyline,
        /// <summary>
        /// Sets the segment type as Bezier.
        /// </summary>
        [EnumMember(Value = "Bezier")]
        Bezier,
    }

    /// <summary>
    /// Specifies the connector decorator shape of the connector
    /// </summary>
    public enum DecoratorShapes
    {
        /// <summary>
        /// Sets the decorator shape as Arrow
        /// </summary>
        [EnumMember(Value = "Arrow")]
        Arrow,
        /// <summary>
        /// Sets the decorator shape as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the decorator shape as Diamond
        /// </summary>
        [EnumMember(Value = "Diamond")]
        Diamond,
        /// <summary>
        /// Sets the decorator shape as OpenArrow
        /// </summary>
        [EnumMember(Value = "OpenArrow")]
        OpenArrow,
        /// <summary>
        /// Sets the decorator shape as Circle
        /// </summary>
        [EnumMember(Value = "Circle")]
        Circle,
        /// <summary>
        /// Sets the decorator shape as Square
        /// </summary>
        [EnumMember(Value = "Square")]
        Square,
        /// <summary>
        /// Sets the decorator shape as Fletch
        /// </summary>
        [EnumMember(Value = "Fletch")]
        Fletch,
        /// <summary>
        /// Sets the decorator shape as OpenFetch
        /// </summary>
        [EnumMember(Value = "OpenFetch")]
        OpenFetch,
        /// <summary>
        /// Sets the decorator shape as Indented Arrow
        /// </summary>
        [EnumMember(Value = "IndentedArrow")]
        IndentedArrow,
        /// <summary>
        /// Sets the decorator shape as Outdented Arrow
        /// </summary>
        [EnumMember(Value = "OutdentedArrow")]
        OutdentedArrow,
        /// <summary>
        /// Sets the decorator shape as DoubleArrow
        /// </summary>
        [EnumMember(Value = "DoubleArrow")]
        DoubleArrow,
        /// <summary>
        /// Sets the decorator shape as Custom
        /// </summary>
        [EnumMember(Value = "Custom")]
        Custom,
    }


    /// <summary>
    /// Specifies the orthogonal connector's connection segment direction.
    /// </summary>
    public enum Direction
    {
        /// <summary>
        /// Sets the direction of the connector segment direction to Left.
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Sets the direction of the connector segment direction to Right.
        /// </summary>
        [EnumMember(Value = "Right")]
        Right,
        /// <summary>
        /// Sets the direction of the connector segment direction to Top.
        /// </summary>
        [EnumMember(Value = "Top")]
        Top,
        /// <summary>
        /// Sets the direction of the connector segment direction to Bottom.
        /// </summary>
        [EnumMember(Value = "Bottom")]
        Bottom,
    }


    internal enum MatrixTypes
    {
        Identity = 0,
        Translation = 1,
        Scaling = 2,
        Unknown = 4
    }

    internal enum ScrollActions
    {
        None = 0,
        PropertyChange = 1 << 1,
        Interaction = 1 << 2,
        PublicMethod = 1 << 3
    }

    /// <summary>
    /// Specifies the type of annotation template
    /// </summary>
    public enum AnnotationType
    {
        /// <summary>
        /// Specifies that the annotation will be string content.
        /// </summary>
        [EnumMember(Value = "String")]
        String,
        /// <summary>
        /// Specifies that the annotation user defined Html template.
        /// </summary>
        [EnumMember(Value = "Template")]
        Template,
    }
    /// <summary>
    /// Annotation constraints control the features and behaviors of the annotations.
    /// </summary>
    [Flags]
    public enum AnnotationConstraints
    {
        /// <summary>
        /// Disables all the functionalities of annotation.
        /// </summary>
        None = 0,
        /// <summary>
        /// It enables the user to only read (cannot be edited) the annotation.
        /// </summary>
        ReadOnly = 1 << 1,
        /// <summary>
        /// Enables or disables the user to inherit the ReadOnly option from the parent.
        /// </summary>
        InheritReadOnly = 1 << 2,
    }
    /// <summary>
    /// Specifies the user to define the type of annotation.
    /// </summary>
    public enum AnnotationTypes
    {
        /// <summary>
        /// Sets the annotation type as Path.
        /// </summary>
        [EnumMember(Value = "Shape")]
        Shape,
        /// <summary>
        /// Sets the annotation type as Shape.
        /// </summary>
        [EnumMember(Value = "Path")]
        Path,
    }

    internal enum NoOfSegments
    {
        Zero,
        One,
        Two,
        Three,
        Four,
        Five
    }
    /// <summary>
    /// Specifies how the diagram elements must be aligned based on its immediate parent.
    /// </summary>
    public enum AnnotationAlignment
    {
        /// <summary>
        /// Annotation placed over the connector segment.
        /// </summary>
        [EnumMember(Value = "Center")]
        Center,
        /// <summary>
        /// Annotation placed top of the connector segment.
        /// </summary>
        [EnumMember(Value = "Before")]
        Before,
        /// <summary>
        /// Annotation placed bottom to the connector segment.
        /// </summary>
        [EnumMember(Value = "After")]
        After,
    }


    /// <summary>
    /// Defines the orientation of the Page
    /// </summary>
    public enum PageOrientation
    {
        /// <summary>
        /// Display with page Width is more than the page Height
        /// </summary>
        Landscape = 1 << 0,

        /// <summary>
        /// Display with page Height is more than the page width
        /// </summary>
        Portrait = 1 << 1
    }


    /// <summary>
    /// Specifies the users to set the region to allow interaction with the diagram.
    /// </summary>
    public enum BoundaryConstraints
    {
        /// <summary>
        /// Allow the interactions to take place at the infinite height and width.
        /// </summary>
        [EnumMember(Value = "Infinity")]
        Infinity,
        /// <summary>
        /// Allow the interactions to take place around the diagram height and width.
        /// </summary>
        [EnumMember(Value = "Diagram")]
        Diagram,
        /// <summary>
        /// Allow the interactions to take place around the height and width mentioned on the page settings.
        /// </summary>
        [EnumMember(Value = "Page")]
        Page,
    }

    /// <summary>
    /// Specifies the region that has to be drawn as an image
    /// </summary>
    public enum DiagramRegions
    {
        /// <summary>
        /// Sets to export the diagram with the given page settings.
        /// </summary>
        [EnumMember(Value = "PageSettings")]
        PageSettings,
        /// <summary>
        /// Sets to export the diagram content alone.
        /// </summary>
        [EnumMember(Value = "Content")]
        Content,
        /// <summary>
        /// Sets to export the diagram with the given bounds.
        /// </summary>
        [EnumMember(Value = "CustomBounds")]
        CustomBounds,
    }

    /// <summary>
    /// Specifies the alignment of the image.
    /// </summary>
    public enum ImageAlignment
    {
        /// <summary>
        /// Sets the none alignments for the image.
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the smallest X value of the view port and  smallest Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMinYMin")]
        XMinYMin,
        /// <summary>
        /// Sets the midpoint X value of the view port and  smallest Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMidYMin")]
        XMidYMin,
        /// <summary>
        /// Sets the maximum X value of the view port and  smallest Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMaxYMin")]
        XMaxYMin,
        /// <summary>
        /// Sets the smallest X value of the view port and  midpoint Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMinYMid")]
        XMinYMid,
        /// <summary>
        /// Sets the smallest X value of the view port and  midpoint Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMidYMid")]
        XMidYMid,
        /// <summary>
        /// Sets the maximum X value of the view port and  midpoint Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMaxYMid")]
        XMaxYMid,
        /// <summary>
        /// Sets the smallest X value of the view port and  maximum Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMinYMax")]
        XMinYMax,
        /// <summary>
        /// Sets the midpoint X value of the view port and  maximum Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMidYMax")]
        XMidYMax,
        /// <summary>
        /// Sets the maximum X value of the view port and  maximum Y value of the view port for the image.
        /// </summary>
        [EnumMember(Value = "XMaxYMax")]
        XMaxYMax,
    }

    /// <summary>
    /// Specifies the scale of the image.
    /// </summary>
    public enum Scale
    {
        /// <summary>
        /// There will be no scaling to the image.
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// It aligns the image to the center of the node.
        /// </summary>
        [EnumMember(Value = "Meet")]
        Meet,
        /// <summary>
        /// It zooms in to fill the node.
        /// </summary>
        [EnumMember(Value = "Slice")]
        Slice,
    }

    /// <summary>
    /// Defines the scrollable region of the diagram.
    /// </summary>
    public enum ScrollLimit
    {
        /// <summary>
        /// Enables scrolling to view the diagram content.
        /// </summary>
        [EnumMember(Value = "Diagram")]
        Diagram,
        /// <summary>
        /// Diagram will be extended, when we try to scroll the diagram.
        /// </summary>
        [EnumMember(Value = "Infinity")]
        Infinity,
        /// <summary>
        /// Enables scrolling to view the specified area.
        /// </summary>
        [EnumMember(Value = "Limited")]
        Limited,
    }
    /// <summary>
    /// Specifies the diagrams stretch.
    /// </summary>
    public enum Stretch
    {
        /// <summary>
        /// Sets the stretch type for diagram as None.
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the stretch type for diagram as Stretch.
        /// </summary>
        [EnumMember(Value = "Stretch")]
        Stretch,
        /// <summary>
        /// Sets the stretch type for diagram as Meet.
        /// </summary>
        [EnumMember(Value = "Meet")]
        Meet,
        /// <summary>
        /// Sets the stretch type for diagram as Slice.
        /// </summary>
        [EnumMember(Value = "Slice")]
        Slice,
    }
    /// <summary>
    /// Specifies the types of the automatic layout.
    /// </summary>
    public enum LayoutType
    {
        /// <summary>
        /// None - None of the layouts is applied.
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the layout as HierarchicalTree.
        /// </summary>
        [EnumMember(Value = "HierarchicalTree")]
        HierarchicalTree,
        /// <summary>
        /// Sets the type of the layout as Organizational Chart.
        /// </summary>
        [EnumMember(Value = "OrganizationalChart")]
        OrganizationalChart,
        /// <summary>
        /// Sets the type of the layout as MindMap
        /// </summary>
        [EnumMember(Value = "MindMap")]
        MindMap
    }
    /// <summary>
    /// Specifies the collection of sub tree orientations in an organizational chart.
    /// </summary>
    public enum SubTreeOrientation
    {
        /// <summary>
        /// Aligns the child nodes in horizontal manner.
        /// </summary>
        [EnumMember(Value = "Horizontal")]
        Horizontal,
        /// <summary>
        /// Aligns the child nodes in vertical manner
        /// </summary>
        [EnumMember(Value = "Vertical")]
        Vertical
    }
    /// <summary>
    /// Specifies the collection of sub tree alignments in an organizational chart
    /// </summary>
    public enum SubTreeAlignments
    {
        /// <summary>
        /// Aligns the child nodes at the left of the parent in a horizontal/vertical sub tree.
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Aligns the child nodes at the right of the parent in a horizontal/vertical sub tree
        /// </summary>
        [EnumMember(Value = "Right")]
        Right,
        /// <summary>
        /// Aligns the child nodes at the center of the parent in a horizontal sub tree
        /// </summary>
        [EnumMember(Value = "Center")]
        Center,
        /// <summary>
        /// Aligns the child nodes at both left and right sides of the parent in a vertical sub tree
        /// </summary>
        [EnumMember(Value = "Alternate")]
        Alternate,
        /// <summary>
        /// Aligns the child nodes in multiple rows to balance the width and height of the horizontal sub tree
        /// </summary>
        [EnumMember(Value = "Balanced")]
        Balanced
    }
    /// <summary>
    /// Specifies the orientation of the layout
    /// </summary>
    public enum LayoutOrientation
    {
        /// <summary>
        /// Aligns the Child nodes will be arranged in linear manner.
        /// </summary>
        [EnumMember(Value = "TopToBottom")]
        TopToBottom,
        /// <summary>
        /// Aligns the child nodes will be arranged in not linear manner
        /// </summary>
        [EnumMember(Value = "BottomToTop")]
        BottomToTop,
        /// <summary>
        /// Aligns the child nodes will be arranged in not linear manner
        /// </summary>
        [EnumMember(Value = "LeftToRight")]
        LeftToRight,
        /// <summary>
        /// Aligns the child nodes will be arranged in not linear manner
        /// </summary>
        [EnumMember(Value = "RightToLeft")]
        RightToLeft
    }

    /// <summary>
    /// Defines the orientation
    /// </summary>
	public enum Orientation
    {
        /// <summary>
        /// Horizontal - Sets the orientation as Horizontal.
        /// </summary>
        [EnumMember(Value = "Horizontal")]
        Horizontal,
        /// <summary>
        /// Vertical - Sets the orientation as Vertical.
        /// </summary>
        [EnumMember(Value = "Vertical")]
        Vertical,
    }

    /// <summary>
    /// Specifies a custom cursor action in diagram.
    /// </summary>
    public enum Actions
    {
        /// <summary>
        /// Disable all actions for cursor.
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the select action for the cursor.
        /// </summary>
        [EnumMember(Value = "Select")]
        Select,
        /// <summary>
        /// Sets the Drag action for the cursor.
        /// </summary>
        [EnumMember(Value = "Drag")]
        Drag,
        /// <summary>
        /// Sets the ResizeWest action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeWest")]
        ResizeWest,
        /// <summary>
        /// Sets the Connector SourceEnd action for the cursor.
        /// </summary>
        [EnumMember(Value = "ConnectorSourceEnd")]
        ConnectorSourceEnd,
        /// <summary>
        /// Sets the Connector TargetEnd action for the cursor.
        /// </summary>
        [EnumMember(Value = "ConnectorTargetEnd")]
        ConnectorTargetEnd,
        /// <summary>
        /// Sets the ResizeEast action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeEast")]
        ResizeEast,
        /// <summary>
        /// Sets the ResizeSouth action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeSouth")]
        ResizeSouth,
        /// <summary>
        /// Sets the select action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeNorth")]
        ResizeNorth,
        /// <summary>
        /// Sets the Resize SouthEast action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeSouthEast")]
        ResizeSouthEast,
        /// <summary>
        /// Sets the Resize SouthWest action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeSouthWest")]
        ResizeSouthWest,
        /// <summary>
        /// Sets the Resize NorthEast action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeNorthEast")]
        ResizeNorthEast,
        /// <summary>
        /// Sets the Resize NorthWest action for the cursor.
        /// </summary>
        [EnumMember(Value = "ResizeNorthWest")]
        ResizeNorthWest,
        /// <summary>
        /// Sets the Rotate action for the cursor.
        /// </summary>
        [EnumMember(Value = "Rotate")]
        Rotate,
        /// <summary>
        /// Sets the Pan action for the cursor.
        /// </summary>
        [EnumMember(Value = "Pan")]
        Pan,
        /// <summary>
        /// Sets the Bezier SourceThumb action for the cursor.
        /// </summary>
        [EnumMember(Value = "BezierSourceThumb")]
        BezierSourceThumb,
        /// <summary>
        /// Sets the Bezier TargetThumb action for the cursor.
        /// </summary>
        [EnumMember(Value = "BezierTargetThumb")]
        BezierTargetThumb,
        /// <summary>
        /// Disable all actions for cursor.
        /// </summary>
        [EnumMember(Value = "SegmentEnd")]
        SegmentEnd,
        /// <summary>
        /// Disable all actions for cursor.
        /// </summary>
        [EnumMember(Value = "OrthogonalThumb")]
        OrthogonalThumb,
        /// <summary>
        /// Sets the FixedUserHandle action for the cursor.
        /// </summary>
        [EnumMember(Value = "FixedUserHandle")]
        FixedUserHandle,
        /// <summary>
        /// Sets the Hyperlink action for the cursor.
        /// </summary>
        [EnumMember(Value = "Hyperlink")]
        Hyperlink,
        /// Sets the Draw action for the cursor.
        /// </summary>
        [EnumMember(Value = "Draw")]
        Draw,
        /// Sets the Draw action for the cursor.
        /// </summary>
        [EnumMember(Value = "PortDraw")]
        PortDraw
    }

    [Flags]
    public enum DiagramTools
    {
        /// <summary>
        /// Disables all the drawing tools.
        /// </summary>
        None = 0,
        /// <summary>
        /// It allows users to select only individual nodes or connectors.
        /// </summary>
        SingleSelect = 1 << 0,
        /// <summary>
        /// It allows users to select multiple nodes and connectors.
        /// </summary>
        MultipleSelect = 1 << 1,
        /// <summary>
        /// It allows users to pan the diagram.
        /// </summary>
        ZoomPan = 1 << 2,
        /// <summary>
        /// Enables/Disable DrawOnce support for the diagram.
        /// </summary>
        DrawOnce = 1 << 3,
        /// <summary>
        /// Enables/Disable ContinuousDraw support for the diagram.
        /// </summary>
        ContinuousDraw = 1 << 4,
        /// <summary>
        /// Sets the drawing tools to default.
        /// </summary>
        Default = 1 << 0 | 1 << 1,
    }

    /// <summary>
    /// Specifies how to handle the selected items via rubber band selection.
    /// </summary>
    public enum RubberBandSelectionMode
    {
        /// <summary>
        /// Selects the objects that are contained within the selected region.
        /// </summary>
        [EnumMember(Value = "CompleteIntersect")]
        CompleteIntersect,
        /// <summary>
        /// Selects the objects that are partially intersected with the selected region.
        /// </summary>
        [EnumMember(Value = "PartialIntersect")]
        PartialIntersect,
    }

    /// <summary>
    /// Specifies the visibility of the selector handles.
    /// </summary>
    [Flags]
    public enum SelectorConstraints
    {
        /// <summary>
        /// Hides all the selector elements.
        /// </summary>
        None = 0,
        /// <summary>
        /// Shows the source thumb of the connector.
        /// </summary>
        ConnectorSourceThumb = 1 << 1,
        /// <summary>
        /// Shows the target thumb of the connector.
        /// </summary>
        ConnectorTargetThumb = 1 << 2,
        /// <summary>
        /// Shows the bottom right resize handle of the selector.
        /// </summary>
        ResizeSouthEast = 1 << 3,
        /// <summary>
        /// Shows the bottom left resize handle of the selector. 
        /// </summary>
        ResizeSouthWest = 1 << 4,
        /// <summary>
        /// Shows the top right resize handle of the selector.
        /// </summary>
        ResizeNorthEast = 1 << 5,
        /// <summary>
        /// Shows the top left resize handle of the selector.
        /// </summary>
        ResizeNorthWest = 1 << 6,
        /// <summary>
        /// Shows the middle right resize handle of the selector.
        /// </summary>
        ResizeEast = 1 << 7,
        /// <summary>
        /// Shows the middle left resize handle of the selector.
        /// </summary>
        ResizeWest = 1 << 8,
        /// <summary>
        /// Shows the bottom center resize handle of the selector.
        /// </summary>
        ResizeSouth = 1 << 9,
        /// <summary>
        /// Shows the top center resize handle of the selector.
        /// </summary>
        ResizeNorth = 1 << 10,
        /// <summary>
        /// Shows the rotate handle of the selector.
        /// </summary>
        Rotate = 1 << 11,
        /// <summary>
        ///  Shows/hides the user handles of the selector .
        /// </summary>
        UserHandle = 1 << 12,
        /// <summary>
        /// Shows all handles of the selector.
        /// </summary>
        All = ResizeAll | Rotate | UserHandle,
        /// <summary>
        /// Shows all resize handles of the selector.
        /// </summary>
        ResizeAll = ResizeSouthEast | ResizeSouthWest | ResizeNorthEast |
    ResizeNorthWest | ResizeEast | ResizeWest | ResizeSouth | ResizeNorth | ConnectorSourceThumb | ConnectorTargetThumb,

    }

    /// <summary>
    /// Specifies whether an object is added/removed from diagram
    /// </summary>
    public enum ChangeType
    {
        /// <summary>
        /// Sets the ChangeType to Addition.
        /// </summary>
        [EnumMember(Value = "Addition")]
        Addition,
        /// <summary>
        /// Sets the ChangeType to Removal.
        /// </summary>
        [EnumMember(Value = "Removal")]
        Removal,
    }

    /// <summary>
    /// Specifies to Enables/Disables certain actions of diagram
    /// </summary>
    [Flags]
    public enum DiagramAction
    {
        ///<summary>
        /// Indicates the diagram is in render state.
        ///</summary>
        Render = 1 << 1,

        /// <summary>
        /// Indicates the diagram public method is in action.
        /// </summary>
        PublicMethod = 1 << 2,

        /// <summary>
        /// Indicates whether drag or rotate tool has been activated.
        /// </summary>
        Interactions = 1 << 3,

        /// <summary>
        /// Indicates whether enable or disble the layouting.
        /// </summary>
        Layouting = 1 << 4,
        /// <summary>
        /// Indicates whether group dragging has been activated.
        /// </summary>
        isGroupDragging = 1 << 5,

        ///<summary>
        ///Indicates the diagram undo/redo is in action
        /// </summary>
        UndoRedo = 1 << 6,
        /// <summary>
        /// Indicates the group is in progress.
        /// </summary>
        Group = 1 << 7,
        ///<summary>
        ///Indicates the diagram drawing tool is enabled
        /// </summary>
        DrawingTool = 1 << 8,
        ///<summary>
        ///Indicates the diagram text annotation edit box is enabled
        /// </summary>
        EditText = 1 << 9,
    }
    [Flags]
    internal enum RealAction
    {
        PreventDrag = 1 << 1,
        PreventScale = 1 << 2,
        PreventDataInit = 1 << 3,
        /// <summary>
        /// Indicates whether JS calling has been made.
        /// </summary>
        MeasureDataJSCall = 1 << 4,

        /// <summary>
        /// Indicates to prevent the whole diagram refresh.
        /// </summary>
        PreventRefresh = 1 << 5,

        /// <summary>
        /// Indicates whether path data is measuring has been made.
        /// </summary>
        PathDataMeasureAsync = 1 << 6,

        /// <summary>
        /// Enable the group action.
        /// </summary>
        EnableGroupAction = 1 << 7,

        /// <summary>
        /// Indicates to prevent the diagram refresh.
        /// </summary>
        PreventEventRefresh = 1 << 8,
        /// <summary>
        /// Indicates to diagram is preformed scroll actions.
        /// </summary>
        ScrollActions = 1 << 9,
        /// <summary>
        /// Indicates to prevent the path data measure.
        /// </summary>
        PreventPathDataMeasure = 1 << 10,
        /// <summary>
        /// Indicates the symbol is being dragged from the palette
        /// </summary>
        SymbolDrag = 1 << 11,

        /// <summary>
        /// Indicates to collection change event is cancelled.
        /// </summary>
        CancelCollectionChange = 1 << 12,
        /// <summary>
        /// Indicates to collection change event is cancelled.
        /// </summary>
        GroupingCollectionChange = 1 << 13,
        /// <summary>
        /// Indicates to refresh the selector layer.
        /// </summary>
        RefreshSelectorLayer = 1 << 14
    }

    /// <summary>
    /// Specifies the events current state
    /// </summary>
    public enum EventState
    {
        /// <summary>
        /// Sets the event state as Changing
        /// </summary>
        [EnumMember(Value = "Changing")]
        Changing,
        /// <summary>
        /// Sets the event state as Changed
        /// </summary>
        [EnumMember(Value = "Changed")]
        Changed
    }

    /// <summary>
    /// Specifies to enables/disbles the handles for the selected items
    /// </summary>
    [Flags]
    internal enum ThumbsConstraints
    {
        None,
        /// <summary>
        /// Sets the source thumb of the connector.
        /// </summary>
        ConnectorSource = 1 << 2,
        /// <summary>
        /// Sets the target thumb of the connector.
        /// </summary>
        ConnectorTarget = 1 << 3,
        /// <summary>
        /// Sets all handles of the selected items.
        /// </summary>
        Default = 1 << 1 | 1 << 2 | 1 << 3 | 1 << 4 | 1 << 5 | 1 << 6 | 1 << 7 | 1 << 8 | 1 << 9 | 1 << 10 | 1 << 11,
        /// <summary>
        /// Sets the middle right resize handle of the selected items.
        /// </summary>
        ResizeEast = 1 << 5,
        /// <summary>
        /// Sets the top center resize handle of the selected items.
        /// </summary>
        ResizeNorth = 1 << 11,
        /// <summary>
        /// Sets the top right resize handle of the selected items.
        /// </summary>
        ResizeNorthEast = 1 << 4,
        /// <summary>
        /// Sets the top left resize handle of the selected items.
        /// </summary>
        ResizeNorthWest = 1 << 10,
        /// <summary>
        /// Sets the bottom center resize handle of the selected items.
        /// </summary>
        ResizeSouth = 1 << 7,
        /// <summary>
        /// Sets the bottom right resize handle of the selected items.
        /// </summary>
        ResizeSouthEast = 1 << 6,
        /// <summary>
        /// Sets the bottom left resize handle of the selected items. 
        /// </summary>
        ResizeSouthWest = 1 << 8,
        /// <summary>
        /// Sets the middle left resize handle of the selected items.
        /// </summary>
        ResizeWest = 1 << 9,
        /// <summary>
        /// Sets the rotate handle of the selected items.
        /// </summary>
        Rotate = 1 << 1
    }
    /// <summary>
    ///  Defines the type of the Bpmn Shape
    /// </summary>
    public enum BpmnShapes
    {
        /// <summary>
        /// Sets the type of the Bpmn Shape as Event
        /// </summary>
        [EnumMember(Value = "Event")]
        Event,
        /// <summary>
        /// Sets the type of the Bpmn Shape as Gateway
        /// </summary>
        [EnumMember(Value = "Gateway")]
        Gateway,
        /// <summary>
        /// Sets the type of the Bpmn Shape as Message
        /// </summary>
        [EnumMember(Value = "Message")]
        Message,
        /// <summary>
        /// Sets the type of the Bpmn Shape as DataObject
        /// </summary>
        [EnumMember(Value = "DataObject")]
        DataObject,
        /// <summary>
        /// Sets the type of the Bpmn Shape as DataSource
        /// </summary>
        [EnumMember(Value = "DataSource")]
        DataSource,
        /// <summary>
        ///  Sets the type of the Bpmn Shape as Activity
        /// </summary>
        [EnumMember(Value = "Activity")]
        Activity,
        /// <summary>
        /// Sets the type of the Bpmn Shape as Group
        /// </summary>
        [EnumMember(Value = "Group")]
        Group,
        /// <summary>
        /// Represents the shape as Text Annotation
        /// </summary>
        [EnumMember(Value = "TextAnnotation")]
        TextAnnotation,
    }

    /// <summary>
    ///  Defines the type of the Bpmn Events
    /// </summary>
    public enum BpmnEvents
    {
        /// <summary>
        /// Sets the type of the Bpmn Event as Start
        /// </summary>
        [EnumMember(Value = "Start")]
        Start,
        /// <summary>
        /// Sets the type of the Bpmn Event as Intermediate
        /// </summary>
        [EnumMember(Value = "Intermediate")]
        Intermediate,
        /// <summary>
        /// Sets the type of the Bpmn Event as End
        /// </summary>
        [EnumMember(Value = "End")]
        End,
        /// <summary>
        /// Sets the type of the Bpmn Event as NonInterruptingStart 
        /// </summary>
        [EnumMember(Value = "NonInterruptingStart")]
        NonInterruptingStart,
        /// <summary>
        /// Sets the type of the Bpmn Event as NonInterruptingIntermediate
        /// </summary>
        [EnumMember(Value = "NonInterruptingIntermediate")]
        NonInterruptingIntermediate,
        /// <summary>
        /// Sets the type of the Bpmn Event as ThrowingIntermediate
        /// </summary>
        [EnumMember(Value = "ThrowingIntermediate")]
        ThrowingIntermediate,

    }
    /// <summary>
    /// Defines the type of the Bpmn Triggers
    /// </summary>
    public enum BpmnTriggers
    {
        /// <summary>
        /// Sets the type of the trigger as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the trigger as Message 
        /// </summary>
        [EnumMember(Value = "Message")]
        Message,
        /// <summary>
        /// Sets the type of the trigger as Timer
        /// </summary>
        [EnumMember(Value = "Timer")]
        Timer,
        /// <summary>
        /// Sets the type of the trigger as Escalation
        /// </summary>
        [EnumMember(Value = "Escalation")]
        Escalation,
        /// <summary>
        /// Sets the type of the trigger as Link
        /// </summary>
        [EnumMember(Value = "Link")]
        Link,
        /// <summary>
        ///  Sets the type of the trigger as Error
        /// </summary>
        [EnumMember(Value = "Error")]
        Error,
        /// <summary>
        /// Sets the type of the trigger as Compensation
        /// </summary>
        [EnumMember(Value = "Compensation")]
        Compensation,
        /// <summary>
        /// Sets the type of the trigger as Signal
        /// </summary>
        [EnumMember(Value = "Signal")]
        Signal,
        /// <summary>
        /// Sets the type of the trigger as Multiple
        /// </summary>
        [EnumMember(Value = "Multiple")]
        Multiple,
        /// <summary>
        /// Sets the type of the trigger as Parallel
        /// </summary>
        [EnumMember(Value = "Parallel")]
        Parallel,
        /// <summary>
        /// Sets the type of the trigger as Cancel 
        /// </summary>
        [EnumMember(Value = "Cancel")]
        Cancel,
        /// <summary>
        /// Sets the type of the trigger as Conditional
        /// </summary>
        [EnumMember(Value = "Conditional")]
        Conditional,
        /// <summary>
        /// Sets the type of the trigger as Terminate
        /// </summary>
        [EnumMember(Value = "Terminate")]
        Terminate
    }
    /// <summary>
    /// Defines the type of the Bpmn gateways
    /// </summary>
    public enum BpmnGateways
    {
        /// <summary>
        /// Sets the type of the gateway as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the gateway as Exclusive
        /// </summary>
        [EnumMember(Value = "Exclusive")]
        Exclusive,
        /// <summary>
        /// Sets the type of the gateway as Inclusive
        /// </summary>
        [EnumMember(Value = "Inclusive")]
        Inclusive,
        /// <summary>
        /// Sets the type of the gateway as Parallel
        /// </summary>
        [EnumMember(Value = "Parallel")]
        Parallel,
        /// <summary>
        /// Sets the type of the gateway as Complex
        /// </summary>
        [EnumMember(Value = "Complex")]
        Complex,
        /// <summary>
        ///  Sets the type of the gateway as EventBased
        /// </summary>
        [EnumMember(Value = "EventBased")]
        EventBased,
        /// <summary>
        /// Sets the type of the gateway as ExclusiveEventBased 
        [EnumMember(Value = "ExclusiveEventBased")]
        ExclusiveEventBased,
        /// <summary>
        /// Sets the type of the gateway as ParallelEventBased
        /// </summary>
        [EnumMember(Value = "ParallelEventBased")]
        ParallelEventBased
    }
    /// <summary>
    /// Defines the type of the Bpmn  Data Objects
    /// </summary>
    public enum BpmnDataObjects
    {
        /// <summary>
        /// Sets the type of the data object as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the data object as Input
        /// </summary>
        [EnumMember(Value = "Input")]
        Input,
        /// <summary>
        /// Sets the type of the data object as Output
        /// </summary>
        [EnumMember(Value = "Output")]
        Output
    }
    /// <summary>
    /// Defines the type of the Bpmn  Activity
    /// </summary>
    public enum BpmnActivities
    {
        /// <summary>
        /// Sets the type of the Bpmn Activity as Task
        /// </summary>
        [EnumMember(Value = "Task")]
        Task,
        /// <summary>
        /// Sets the type of the Bpmn Activity as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the Bpmn Activity as SubProcess 
        /// </summary>
        [EnumMember(Value = "SubProcess")]
        SubProcess
    }
    /// <summary>
    /// Defines the type of the Bpmn Loops
    /// </summary>
    public enum BpmnLoops
    {
        /// <summary>
        /// Sets the type of the Bpmn loop as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the Bpmn loop as Standard
        /// </summary>
        [EnumMember(Value = "Standard")]
        Standard,
        /// <summary>
        /// Sets the type of the Bpmn loop as ParallelMultiInstance
        /// </summary>
        [EnumMember(Value = "ParallelMultiInstance")]
        ParallelMultiInstance,
        /// <summary>
        /// Sets the type of the Bpmn loop as SequenceMultiInstance
        /// </summary>
        [EnumMember(Value = "SequenceMultiInstance")]
        SequenceMultiInstance
    }
    /// <summary>
    /// Defines the type of the Bpmn Tasks
    /// </summary>
    public enum BpmnTasks
    {
        /// <summary>
        /// Sets the type of the Bpmn Tasks as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the Bpmn Tasks as Service
        /// </summary>
        [EnumMember(Value = "Service")]
        Service,
        /// <summary>
        /// Sets the type of the Bpmn Tasks as Receive
        /// </summary>
        [EnumMember(Value = "Receive")]
        Receive,
        /// <summary>
        /// Sets the type of the Bpmn Tasks as Send
        /// </summary>
        [EnumMember(Value = "Send")]
        Send,
        /// <summary>
        /// Sets the type of the Bpmn Tasks as InstantiatingReceive
        /// </summary>
        [EnumMember(Value = "InstantiatingReceive")]
        InstantiatingReceive,
        /// <summary>
        ///  Sets the type of the Bpmn Tasks as Manual
        /// </summary>
        [EnumMember(Value = "Manual")]
        Manual,
        /// <summary>
        /// Sets the type of the Bpmn Tasks as BusinessRule 
        /// </summary>
        [EnumMember(Value = "BusinessRule")]
        BusinessRule,
        /// <summary>
        /// Sets the type of the Bpmn Tasks as User
        /// </summary>
        [EnumMember(Value = "User")]
        User,
        /// <summary>
        /// SSets the type of the Bpmn Tasks as Script
        /// </summary>
        [EnumMember(Value = "Script")]
        Script
    }
    /// <summary>
    /// Defines the type of the Bpmn Subprocess
    /// </summary>
    public enum BpmnSubProcessTypes
    {
        /// <summary>
        /// Sets the type of the Sub process as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the Sub process as Transaction
        /// </summary>
        [EnumMember(Value = "Transaction")]
        Transaction,
        /// <summary>
        /// Sets the type of the Sub process as Event
        /// </summary>
        [EnumMember(Value = "Event")]
        Event
    }
    /// <summary>
    /// Defines the type of the Bpmn boundary
    /// </summary>
    public enum BpmnBoundary
    {
        /// <summary>
        /// Sets the type of the boundary as Default
        /// </summary>
        [EnumMember(Value = "Default")]
        Default,
        /// <summary>
        /// Sets the type of the boundary as Call
        /// </summary>
        [EnumMember(Value = "Call")]
        Call,
        /// <summary>
        /// Sets the type of the boundary as Event
        /// </summary>
        [EnumMember(Value = "Event")]
        Event
    }
    /// <summary>
    /// Defines the type of the Bpmn flows
    /// </summary>
    public enum BpmnFlows
    {
        /// <summary>
        /// Sets the type of the Bpmn Flow as Sequence
        /// </summary>
        [EnumMember(Value = "Sequence")]
        Sequence,
        /// <summary>
        /// Sets the type of the Bpmn Flow as Association
        /// </summary>
        [EnumMember(Value = "Association")]
        Association,
        /// <summary>
        /// Sets the type of the Bpmn Flow as Message
        /// </summary>
        [EnumMember(Value = "Message")]
        Message
    }
    /// <summary>
    /// Defines the type of the Bpmn Association Flows
    /// </summary>
    public enum BpmnAssociationFlows
    {
        /// <summary>
        /// Sets the type of Association flow as Default
        /// </summary>
        [EnumMember(Value = "Default")]
        Default,
        /// <summary>
        /// Sets the type of Association flow as Directional
        /// </summary>
        [EnumMember(Value = "Directional")]
        Directional,
        /// <summary>
        /// Sets the type of Association flow as BiDirectional
        /// </summary>
        [EnumMember(Value = "BiDirectional")]
        BiDirectional
    }
    /// <summary>
    /// Defines the type of the Bpmn Message Flows
    /// </summary>
    public enum BpmnMessageFlows
    {
        /// <summary>
        /// Sets the type of the Message flow as Default
        /// </summary>
        [EnumMember(Value = "Default")]
        Default,
        /// <summary>
        /// Sets the type of the Message flow as InitiatingMessage
        /// </summary>
        [EnumMember(Value = "InitiatingMessage")]
        InitiatingMessage,
        /// <summary>
        /// Sets the type of the Message flow as NonInitiatingMessage
        /// </summary>
        [EnumMember(Value = "NonInitiatingMessage")]
        NonInitiatingMessage
    }
    /// <summary>
    /// Defines the type of the Bpmn Sequence flows
    /// </summary>
    public enum BpmnSequenceFlows
    {
        /// <summary>
        /// Sets the type of the sequence flow as Normal
        /// </summary>
        [EnumMember(Value = "Normal")]
        Normal,
        /// <summary>
        /// Sets the type of the sequence flow as Default
        /// </summary>
        [EnumMember(Value = "Default")]
        Default,
        /// <summary>
        /// Sets the type of the sequence flow as Conditional
        /// </summary>
        [EnumMember(Value = "Conditional")]
        Conditional
    }
    /// <summary>
    /// Defines the connection shapes
    /// </summary>
    public enum ConnectionShapes
    {
        /// <summary>
        /// Sets the type of the connection shape as None
        /// </summary>
        [EnumMember(Value = "None")]
        None,
        /// <summary>
        /// Sets the type of the connection shape as Bpmn
        /// </summary>
        [EnumMember(Value = "Bpmn")]
        Bpmn,
        /// <summary>
        /// Sets the type of the connection shape as UMLActivity
        /// </summary>
        [EnumMember(Value = "UmlActivity")]
        UmlActivity,
        /// <summary>
        /// Sets the type of the connection shape as UMLClassifier
        /// </summary>
        [EnumMember(Value = "UmlClassifier")]
        UmlClassifier
    }
    /// <summary>
    /// Defines the Alignment position
    /// </summary>
    public enum BranchTypes
    {
        /// <summary>
        /// Left - Sets the branch type as Left
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Right - Sets the branch type as Right
        /// </summary>
        [EnumMember(Value = "Right")]
        Right,
        /// <summary>
        /// SubLeft - Sets the branch type as SubLeft
        /// </summary>
        [EnumMember(Value = "SubLeft")]
        SubLeft,
        /// <summary>
        /// SubRight - Sets the branch type as SubRight
        /// </summary>
        [EnumMember(Value = "SubRight")]
        SubRight,
        /// <summary>
        /// Sets the branch type as Root
        /// </summary>
        [EnumMember(Value = "Root")]
        Root
    }

    /// <summary>
    /// Defines where the user handles have to be aligned
    /// </summary>
    public enum Side
    {
        /// <summary>
        /// Aligns the user handles at the top of an object
        /// </summary>
        [EnumMember(Value = "Top")]
        Top,
        /// <summary>
        /// Aligns the user handles at the bottom of an object
        /// </summary>
        [EnumMember(Value = "Bottom")]
        Bottom,
        /// <summary>
        /// Aligns the user handles at the left of an object
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Aligns the user handles at the right of an object
        /// </summary>
        [EnumMember(Value = "Right")]
        Right
    }

    /// <summary>
    /// Specifies the state of interactions such as drag, resize, and rotate.
    /// </summary>
    public enum State
    {
        /// <summary>
        /// Sets the interaction state to start.
        /// </summary>
        [EnumMember(Value = "Start")]
        Start,
        /// <summary>
        /// Sets the interaction state to progress.
        /// </summary>
        [EnumMember(Value = "Progress")]
        Progress,
        /// <summary>
        /// Sets the interaction state to completed.
        /// </summary>
        [EnumMember(Value = "Completed")]
        Completed,
    }
    internal enum SymbolPaletteEvent
    {
        [EnumMember(Value = "PaletteSelectionChange")]
        PaletteSelectionChange,
        [EnumMember(Value = "PaletteNodeDefaults")]
        PaletteNodeDefaults,
        [EnumMember(Value = "PaletteConnectorDefaults")]
        PaletteConnectorDefaults,
        [EnumMember(Value = "OnExpanding")]
        OnExpanding
    }
    internal enum DiagramEvent
    {
        [EnumMember(Value = "SelectionChange")]
        SelectionChange,
        [EnumMember(Value = "PositionChange")]
        PositionChange,
        [EnumMember(Value = "ConnectionChange")]
        ConnectionChange,
        [EnumMember(Value = "SourcePointChange")]
        SourcePointChange,
        [EnumMember(Value = "TargetPointChange")]
        TargetPointChange,
        [EnumMember(Value = "FixedUserHandleClick")]
        FixedUserHandleClick,
        [EnumMember(Value = "RotateChange")]
        RotateChange,
        [EnumMember(Value = "SizeChange")]
        SizeChange,
        [EnumMember(Value = "HistoryChange")]
        HistoryChange,
        [EnumMember(Value = "CanLog")]
        CanLog,
        [EnumMember(Value = "Undo")]
        Undo,
        [EnumMember(Value = "Redo")]
        Redo,
        [EnumMember(Value = "Drop")]
        Drop,
        [EnumMember(Value = "DragOver")]
        DragOver,
        [EnumMember(Value = "DragEnter")]
        DragEnter,
        [EnumMember(Value = "DragLeave")]
        DragLeave,
        [EnumMember(Value = "KeyDown")]
        KeyDown,
        [EnumMember(Value = "KeyUp")]
        KeyUp,
        [EnumMember(Value = "CollectionChange")]
        CollectionChange,
        [EnumMember(Value = "SegmentCollectionChange")]
        SegmentCollectionChange,
        [EnumMember(Value = "Click")]
        Click,
        [EnumMember(Value = "MouseEnter")]
        MouseEnter,
        [EnumMember(Value = "MouseOver")]
        MouseOver,
        [EnumMember(Value = "MouseLeave")]
        MouseLeave,
        [EnumMember(Value = "ScrollChange")]
        ScrollChange,
        [EnumMember(Value = "PropertyChange")]
        PropertyChange,
        [EnumMember(Value = "TextEdit")]
        TextEdit
    }
    ///<summary>
    /// Sets a combination of key modifiers, on recognition of which the command will be executed
    /// </summary>
    public enum KeyModifiers
    {
        ///<summary>
        /// No modifiers are pressed
        /// </summary>
        None = 0,
        ///<summary>
        /// The CTRL key
        /// </summary>
        Control = 1 << 0,
        ///<summary>
        /// The Meta key pressed in Mac
        /// </summary>
        Meta = 1 << 0,
        ///<summary>
        /// The ALT key
        /// </summary>
        Alt = 1 << 1,
        ///<summary>
        /// The Shift key
        /// </summary>
        Shift = 1 << 2,
    }
    ///<summary>
    /// Sets the key value, on recognition of which the command will be executed
    /// </summary>
    public enum Keys
    {
        ///<summary>
        /// No key pressed
        /// </summary>
        None,
        ///<summary>
        /// The 0 key
        /// </summary>
        Number0 = 0,
        ///<summary>
        /// The 1 key
        /// </summary>
        Number1 = 1,
        ///<summary>
        /// The 2 key
        /// </summary>
        Number2 = 2,
        ///<summary>
        /// The 3 key
        /// </summary>
        Number3 = 3,
        ///<summary>
        /// The 4 pressed
        /// </summary>
        Number4 = 4,
        ///<summary>
        /// The 5 pressed
        /// </summary>
        Number5 = 5,
        ///<summary>
        /// The 6 key
        /// </summary>
        Number6 = 6,
        ///<summary>
        /// The 7 key
        /// </summary>
        Number7 = 7,
        ///<summary>
        /// The 8 pressed
        /// </summary>
        Number8 = 8,
        ///<summary>
        /// The 9 key
        /// </summary>
        Number9 = 9,
        ///<summary>
        /// The A key
        /// </summary>
        A = 65,
        ///<summary>
        /// The B key
        /// </summary>
        B = 66,
        ///<summary>
        /// The C key
        /// </summary>
        C = 67,
        ///<summary>
        /// The D key
        /// </summary>
        D = 68,
        ///<summary>
        /// The E key
        /// </summary>
        E = 69,
        ///<summary>
        /// The F pressed
        /// </summary>
        F = 70,
        ///<summary>
        /// The G pressed
        /// </summary>
        G = 71,
        ///<summary>
        /// The H key
        /// </summary>
        H = 72,
        ///<summary>
        /// The I key
        /// </summary>
        I = 73,
        ///<summary>
        /// The J pressed
        /// </summary>
        J = 74,
        ///<summary>
        /// The K key
        /// </summary>
        K = 75,
        ///<summary>
        /// The L key
        /// </summary>
        L = 76,
        ///<summary>
        /// The M key
        /// </summary>
        M = 77,
        ///<summary>
        /// The N key
        /// </summary>
        N = 78,
        ///<summary>
        /// The O key
        /// </summary>
        O = 79,
        ///<summary>
        /// The P key
        /// </summary>
        P = 80,
        ///<summary>
        /// The Q key
        /// </summary>
        Q = 81,
        ///<summary>
        /// The R key
        /// </summary>
        R = 82,
        ///<summary>
        /// The S key
        /// </summary>
        S = 83,
        ///<summary>
        /// The T key
        /// </summary>
        T = 84,
        ///<summary>
        /// The U key
        /// </summary>
        U = 85,
        ///<summary>
        /// The V key
        /// </summary>
        V = 86,
        ///<summary>
        /// The W key
        /// </summary>
        W = 87,
        ///<summary>
        /// The X key
        /// </summary>
        X = 88,
        ///<summary>
        /// The Y key
        /// </summary>
        Y = 89,
        ///<summary>
        /// The Z key
        /// </summary>
        Z = 90,
        ///<summary>
        /// The left arrow key
        /// </summary>
        ArrowLeft = 37,
        ///<summary>
        /// The up arrow key
        /// </summary>
        ArrowUp = 38,
        ///<summary>
        /// The right arrow key
        /// </summary>
        ArrowRight = 39,
        ///<summary>
        /// The down arrow key
        /// </summary>
        ArrowDown = 40,
        ///<summary>
        /// The Escape key
        /// </summary>
        Escape = 27,
        ///<summary>
        /// The space key
        /// </summary> 
        Space = 32,
        ///<summary>
        /// The page up key
        /// </summary>
        PageUp = 33,
        ///<summary>
        /// The page down key
        /// </summary>
        PageDown = 34,
        ///<summary>
        /// The end key
        /// </summary>
        End = 35,
        ///<summary>
        /// The home key
        /// </summary>
        Home = 36,
        ///<summary>
        /// The delete key
        /// </summary>
        Delete = 46,
        ///<summary>
        /// The tab key
        /// </summary>
        Tab = 9,
        ///<summary>
        /// The enter key
        /// </summary>
        Enter = 13,
        ///<summary>
        /// The BackSpace key
        /// </summary>
        BackSpace = 8,
        ///<summary>
        /// The F1 key
        /// </summary>
        F1 = 112,
        ///<summary>
        /// The F2 key
        /// </summary>
        F2 = 113,
        ///<summary>
        /// The F3 key
        /// </summary>
        F3 = 114,
        ///<summary>
        /// The F4 key
        /// </summary>
        F4 = 115,
        ///<summary>
        /// The F5 key
        /// </summary>
        F5 = 116,
        ///<summary>
        /// The F6 key
        /// </summary>
        F6 = 117,
        ///<summary>
        /// The F7 key
        /// </summary>
        F7 = 118,
        ///<summary>
        /// The F8 key
        /// </summary>
        F8 = 119,
        ///<summary>
        /// The F9 key
        /// </summary>
        F9 = 120,
        ///<summary>
        /// The F10 key
        /// </summary>
        F10 = 121,
        ///<summary>
        /// The F11 key
        /// </summary>
        F11 = 122,
        ///<summary>
        /// The F12 key
        /// </summary>
        F12 = 123,
        ///<summary>
        /// The Star
        /// </summary>
        Star = 56,
        ///<summary>
        /// The Plus
        /// </summary>
        Plus = 187,
        ///<summary>
        /// The Minus
        /// </summary>
        Minus = 189
    }
    ///<summary>
    /// Defines the nudging direction
    /// </summary>
    public enum NudgeDirection
    {
        ///<summary>
        /// Nudge the object in the left direction
        /// </summary>
        Left,
        ///<summary>
        /// Nudge the object in the right direction
        /// </summary>
        Right,
        ///<summary>
        /// Nudge the object in the up direction
        /// </summary>
        Up,
        ///<summary>
        /// Nudge the object in the down direction
        /// </summary>
        Down
    }
    /// <summary>
    /// Specifies the constraints to Enables / Disables some features of Snapping.
    /// </summary>
    public enum SnapConstraints
    {
        /// <summary>
        /// Snapping does not happen
        /// </summary>
        None = 0,
        /// <summary>
        /// Displays only the horizontal gridlines in diagram.
        /// </summary>
        ShowHorizontalLines = 1 << 0,
        /// <summary>
        /// Displays only the Vertical gridlines in diagram
        /// </summary>
        ShowVerticalLines = 1 << 1,
        /// <summary>
        /// Display both Horizontal and Vertical gridlines
        /// </summary>
        ShowLines = 1 | 2,
        /// <summary>
        /// Enables the object to snap only with horizontal gridlines
        /// </summary>
        SnapToHorizontalLines = 1 << 2,
        /// <summary>
        /// Enables the object to snap only with horizontal gridlines
        /// </summary>
        SnapToVerticalLines = 1 << 3,
        /// <summary>
        /// Enables the object to snap with both horizontal and Vertical gridlines
        /// </summary>
        SnapToLines = 4 | 8,
        /// <summary>
        /// Enables the object to snap with the other objects in the diagram.
        /// </summary>
        SnapToObject = 1 << 4,
        /// <summary>
        /// Shows gridlines and enables snapping
        /// </summary>
        All = 1 | 2 | 4 | 8 | 16
    }

    /// <summary>
    /// Specifies the bridge direction.
    /// </summary>
    public enum BridgeDirection
    {
        /// <summary>
        /// Sets the direction of the bridge as Left.
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Sets the direction of the bridge as Right.
        /// </summary>
        [EnumMember(Value = "Right")]
        Right,
        /// <summary>
        /// Sets the direction of the bridge as Top.
        /// </summary>
        [EnumMember(Value = "Top")]
        Top,
        /// <summary>
        /// Sets the direction of the bridge as Bottom.
        /// </summary>
        [EnumMember(Value = "Bottom")]
        Bottom,
    }

    internal enum SnapAlignment
    {
        Left,
        Right,
        Top,
        Bottom,
        TopBottom,
        BottomTop,
        LeftRight,
        RightLeft,
        CenterX,
        CenterY
    }

    ///<summary>
    /// Defines the entrytype
    /// </summary>
    public enum EntryType
    {
        ///<summary>
        ///PositionChanged - Sets the entry type as PositionChanged 
        /// </summary>
        [EnumMember(Value = "PositionChanged")]
        PositionChanged,
        ///<summary>
        ///ConnectionChanged - Sets the entry type as ConnectionChanged 
        /// </summary>
        [EnumMember(Value = "ConnectionChanged")]
        ConnectionChanged,
        ///<summary>
        ///StartGroup - Sets the entry type as StartGroup
        /// </summary>
        [EnumMember(Value = "StartGroup")]
        StartGroup,
        ///<summary>
        ///EndGroup - Sets the entry type as EndGroup
        /// </summary>
        [EnumMember(Value = "EndGroup")]
        EndGroup,
        ///<summary>
        ///RotationChanged - Sets the entry type as RotationChanged
        /// </summary>
        [EnumMember(Value = "RotationChanged")]
        RotationChanged,
        ///<summary>
        ///PropertyChanged - Sets the entry type as PropertyChanged
        /// </summary>
        [EnumMember(Value = "PropertyChanged")]
        PropertyChanged,
        ///<summary>
        ///CollectionChanged - Sets the entry type as CollectionChanged
        /// </summary>
        [EnumMember(Value = "CollectionChanged")]
        CollectionChanged,
        ///<summary>
        ///LabelCollectionChanged - Sets the entry type as LabelCollectionChanged
        /// </summary>
        [EnumMember(Value = "LabelCollectionChanged")]
        LabelCollectionChanged,
        ///<summary>
        ///PortCollectionChanged - Sets the entry type as PortCollectionChanged
        /// </summary>
        [EnumMember(Value = "PortCollectionChanged")]
        PortCollectionChanged,
        ///<summary>
        ///Group - Sets the entry type as Group
        /// </summary>
        [EnumMember(Value = "Group")]
        Group,
        ///<summary>
        ///UnGroup - Sets the entry type as UnGroup
        /// </summary>
        [EnumMember(Value = "UnGroup")]
        UnGroup,
        ///<summary>
        ///SegmentChanged - Sets the entry type as SegmentChanged
        /// </summary>
        [EnumMember(Value = "SegmentChanged")]
        SegmentChanged,
        ///<summary>
        ///AnnotationPropertyChanged - Sets the entry type as AnnotationPropertyChanged
        /// </summary>
        [EnumMember(Value = "AnnotationPropertyChanged")]
        AnnotationPropertyChanged,
        ///<summary>
        ///Undo - Sets the entry type as Undo
        /// </summary>
        [EnumMember(Value = "Undo")]
        Undo,
        ///<summary>
        ///Redo - Sets the entry type as Redo
        /// </summary>
        [EnumMember(Value = "Redo")]
        Redo,
        ///<summary>
        ///SizeChanged - Sets the entry type as SizeChanged
        /// </summary>
        [EnumMember(Value = "SizeChanged")]
        SizeChanged,
    }

    ///<summary>
    /// Defines the entry category type
    /// </summary>
    public enum EntryCategory
    {
        ///<summary>
        /// Internal - Sets the entry category type as Internal
        /// </summary>       
        InternalEntry,
        ///<summary>
        /// External - Sets the entry category type as External
        /// </summary>   
        ExternalEntry
    }

    public enum HistoryChangeAction
    {
        /** CustomAction - Defines the history action is customaction */
        CustomAction,
        /** Undo - Defines the history action is Undo */
        Undo,
        /** Redo - Defines the history action is Redo */
        Redo
    }

    /// <summary>
    /// Specifies the mouse click action.
    /// </summary>
    public enum MouseButtons
    {
        /// <summary>
        /// Whenever the left button of the mouse is clicked, ‘Left’ is returned.
        /// </summary>
        [EnumMember(Value = "Left")]
        Left,
        /// <summary>
        /// Whenever the mouse wheel is clicked, ‘Middle’ is returned.
        /// </summary>
        [EnumMember(Value = "Middle")]
        Middle,
        /// <summary>
        /// Whenever the right button of the mouse is clicked, ‘Right’ is returned.
        /// </summary>
        [EnumMember(Value = "Right")]
        Right,
    }
    /// <summary>
    /// Define a change type for history entry
    /// </summary>
    public enum EntryChangeType
    {
        /// <summary>
        /// Defines to none of the history entry to insert/remove
        /// </summary>
        None,
        /// <summary>
        /// Defines the history change type is Insert
        /// </summary>
        Insert,
        /// <summary>
        /// Defines the history change type is Remove
        /// </summary>
        Remove
    }
}