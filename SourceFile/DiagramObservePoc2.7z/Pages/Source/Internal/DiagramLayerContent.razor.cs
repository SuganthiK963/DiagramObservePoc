using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Syncfusion.Blazor.Diagram.Internal
{
    /// <summary>
    /// Represents the rendering of the diagram objects
    /// </summary>
    public partial class DiagramLayerContent
    {
        
        [CascadingParameter]
        internal SfDiagramComponent Parent { get; set; }
        [Inject]
        internal IJSRuntime JSRuntime { get; set; }        
    }
}