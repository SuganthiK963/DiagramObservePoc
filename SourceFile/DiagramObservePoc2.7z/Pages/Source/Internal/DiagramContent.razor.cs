using Microsoft.AspNetCore.Components;
using System.Threading.Tasks;


namespace Syncfusion.Blazor.Diagram.Internal
{
    /// <summary>
    /// Represents the rendering of the diagram objects
    /// </summary>
    public partial class DiagramContent
    {
        [CascadingParameter]
        internal SfDiagramComponent Parent { get; set; }

        internal DiagramLayerContent DiagramLayerContent;
        protected override bool ShouldRender()
        {
            if (Parent.RealAction.HasFlag(RealAction.PreventRefresh) && !Parent.RealAction.HasFlag(RealAction.ScrollActions))
            {
                return false;
            }
            return true;
        }

        protected override Task OnAfterRenderAsync(bool firstRender)
        {
            if (Parent != null && DiagramLayerContent != null && Parent.DiagramContent == null)
            {
                Parent.DiagramContent = DiagramLayerContent;
            }
            return Task.CompletedTask;
        }
    }
}
